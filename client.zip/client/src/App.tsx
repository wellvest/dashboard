import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { DashboardLayout } from "./components/layout/DashboardLayout";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { UserDataProvider } from "./contexts/UserDataContext";
import { InvestmentProvider } from "./contexts/InvestmentContext";
import { WalletProvider } from "./contexts/WalletContext";
import { NetworkProvider } from "./contexts/NetworkContext";
import Dashboard from "./pages/Dashboard";
import Investment from "./pages/Investment";
import IncomeWallet from "./pages/IncomeWallet";
import Bonus from "./pages/Bonus";
import Network from "./pages/Network";
import KYC from "./pages/profile/KYC";
import Address from "./pages/profile/Address";
import Bank from "./pages/profile/Bank";
import Profile from "./pages/Profile";
import ResetPassword from "./pages/ResetPassword";
import ShoppingVoucher from "./pages/ShoppingVoucher";
import ShoppingWallet from "./pages/ShoppingWallet";
import NOC from "./pages/NOC";
import TeamPlan from "./pages/TeamPlan";
import MyPlan from "./pages/MyPlan";
import Achievers from "./pages/Achievers";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ForgotPassword from "./pages/ForgotPassword";

// Admin pages
import AdminDashboard from "./pages/admin";
import KYCVerification from "./pages/admin/kyc-verification";
import UserManagement from "./pages/admin/users";

const queryClient = new QueryClient();

// Protected route component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
    </div>;
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  return <>{children}</>;
};

// Admin protected route component
const AdminProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, isLoading, user } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
    </div>;
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }
  
  // Check if user is admin
  if (!user?.email?.endsWith('@admin.wellvest.com')) {
    return <Navigate to="/dashboard" />;
  }
  
  return <>{children}</>;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <UserDataProvider>
        <InvestmentProvider>
          <WalletProvider>
            <NetworkProvider>
              <TooltipProvider>
                <Toaster />
                <Sonner />
                <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            
            {/* Protected Routes */}
            <Route path="/" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Dashboard />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/profile" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Profile />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/profile/kyc" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <KYC />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/profile/address" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Address />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/profile/bank" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Bank />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/reset-password" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <ResetPassword />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/achievers" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Achievers />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/network" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Network />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/shopping-voucher" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <ShoppingVoucher />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/shopping-wallet" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <ShoppingWallet />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/noc" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <NOC />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/bonus" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <Bonus />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/income-wallet" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <IncomeWallet />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/plan" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <MyPlan />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            <Route path="/plan/team" element={
              <ProtectedRoute>
                <DashboardLayout>
                  <TeamPlan />
                </DashboardLayout>
              </ProtectedRoute>
            } />
            
            {/* Admin Routes */}
            <Route path="/admin" element={
              <AdminProtectedRoute>
                <AdminDashboard />
              </AdminProtectedRoute>
            } />
            <Route path="/admin/kyc-verification" element={
              <AdminProtectedRoute>
                <KYCVerification />
              </AdminProtectedRoute>
            } />
            <Route path="/admin/users" element={
              <AdminProtectedRoute>
                <UserManagement />
              </AdminProtectedRoute>
            } />
            
            {/* Catch-all route */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
                </TooltipProvider>
              </NetworkProvider>
            </WalletProvider>
          </InvestmentProvider>
      </UserDataProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
