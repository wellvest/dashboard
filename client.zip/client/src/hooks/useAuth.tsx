import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import axios from 'axios';

// Define user type
export interface User {
  id: string;
  name: string;
  email: string;
  member_id: string;
  avatar?: string;
}

// Define profile type
export interface Profile {
  id: string;
  user_id: string;
  plan_amount: number;
  kyc_verified: boolean;
  kyc_document_type: string | null;
  kyc_document_number: string | null;
  kyc_document_url: string | null;
}

// Define auth context type
interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  fetchUserProfile: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

// Create auth context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Auth provider props
interface AuthProviderProps {
  children: ReactNode;
}

// Create auth provider
export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is already logged in on mount
  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          // Set default auth header
          axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
          await fetchUserProfile();
        } catch (err) {
          console.error('Auth check failed:', err);
          localStorage.removeItem('token');
          delete axios.defaults.headers.common['Authorization'];
        }
      }
      setLoading(false);
    };

    checkAuth();
  }, []);

  // Login function
  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.post('/api/auth/login', {
        email,
        password,
      });
      
      const { access_token } = response.data;
      
      // Save token to localStorage
      localStorage.setItem('token', access_token);
      
      // Set default auth header
      axios.defaults.headers.common['Authorization'] = `Bearer ${access_token}`;
      
      // Fetch user profile
      await fetchUserProfile();
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Login failed');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('token');
    delete axios.defaults.headers.common['Authorization'];
    setUser(null);
    setProfile(null);
  };

  // Fetch user profile
  const fetchUserProfile = async () => {
    try {
      setLoading(true);
      
      // Get user data
      const userResponse = await axios.get('/api/users/me');
      setUser(userResponse.data);
      
      // Get complete profile data
      const profileResponse = await axios.get('/api/users/me/profile');
      setUser(profileResponse.data.user);
      setProfile(profileResponse.data.profile);
      
      return profileResponse.data;
    } catch (err: any) {
      console.error('Failed to fetch user profile:', err);
      setError(err.response?.data?.detail || 'Failed to fetch user profile');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Refresh user data only (not the full profile)
  const refreshUser = async () => {
    try {
      const userResponse = await axios.get('/api/users/me');
      setUser(userResponse.data);
      return userResponse.data;
    } catch (err: any) {
      console.error('Failed to refresh user data:', err);
      throw err;
    }
  };

  const value = {
    user,
    profile,
    loading,
    error,
    login,
    logout,
    fetchUserProfile,
    refreshUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Hook to use auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
