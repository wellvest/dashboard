import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { api } from '../utils/api';

// Define types for wallet data
interface IncomeWallet {
  id: string;
  user_id: string;
  balance: number;
  created_at: string;
  updated_at: string;
}

interface ShoppingWallet {
  id: string;
  user_id: string;
  balance: number;
  created_at: string;
  updated_at: string;
}

interface Transaction {
  id: string;
  wallet_id: string;
  amount: number;
  transaction_type: string;
  description: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface ShoppingVoucher {
  id: string;
  wallet_id: string;
  code: string;
  amount: number;
  is_used: boolean;
  expiry_date: string;
  created_at: string;
  updated_at: string;
}

interface WalletData {
  incomeWallet: IncomeWallet | null;
  shoppingWallet: ShoppingWallet | null;
  transactions: Transaction[];
  vouchers: ShoppingVoucher[];
  loading: boolean;
  error: string | null;
}

interface WalletContextType {
  walletData: WalletData;
  fetchWalletData: () => Promise<void>;
  createTransaction: (walletType: 'income' | 'shopping', data: Omit<Transaction, 'id' | 'wallet_id' | 'created_at' | 'updated_at'>) => Promise<Transaction>;
  createVoucher: (data: Omit<ShoppingVoucher, 'id' | 'wallet_id' | 'created_at' | 'updated_at'>) => Promise<ShoppingVoucher>;
  useVoucher: (id: string) => Promise<ShoppingVoucher>;
  totalIncomeBalance: number;
  totalShoppingBalance: number;
}

// Initial data
const initialWalletData: WalletData = {
  incomeWallet: null,
  shoppingWallet: null,
  transactions: [],
  vouchers: [],
  loading: false,
  error: null
};

// Create the context
const WalletContext = createContext<WalletContextType | undefined>(undefined);

// Provider component
export function WalletProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth();
  const [walletData, setWalletData] = useState<WalletData>(initialWalletData);

  // Calculate total balances
  const totalIncomeBalance = walletData.incomeWallet?.balance || 0;
  const totalShoppingBalance = walletData.shoppingWallet?.balance || 0;

  // Fetch wallet data from API
  const fetchWalletData = async () => {
    if (!isAuthenticated) return;
    
    setWalletData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      // Fetch income wallet
      const incomeWallet = await api.wallets.getIncomeWallet();
      
      // Fetch shopping wallet
      const shoppingWallet = await api.wallets.getShoppingWallet();
      
      // Fetch transactions - combine income and shopping transactions
      const incomeTransactions = await api.wallets.getIncomeTransactions();
      const shoppingTransactions = await api.wallets.getShoppingTransactions();
      const transactions = [...incomeTransactions, ...shoppingTransactions];
      
      // Fetch vouchers
      const vouchers = await api.wallets.getShoppingVouchers();
      
      setWalletData({
        incomeWallet,
        shoppingWallet,
        transactions,
        vouchers,
        loading: false,
        error: null
      });
    } catch (error) {
      console.error('Error fetching wallet data:', error);
      setWalletData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to load wallet data. Please try again.'
      }));
    }
  };

  // Create a new transaction
  const createTransaction = async (
    walletType: 'income' | 'shopping', 
    data: Omit<Transaction, 'id' | 'wallet_id' | 'created_at' | 'updated_at'>
  ): Promise<Transaction> => {
    setWalletData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      let newTransaction;
      
      if (walletType === 'income') {
        newTransaction = await api.wallets.createIncomeTransaction(data);
      } else {
        newTransaction = await api.wallets.createShoppingTransaction(data);
      }
      
      // Update wallet data after transaction
      await fetchWalletData();
      
      return newTransaction;
    } catch (error) {
      console.error('Error creating transaction:', error);
      setWalletData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to create transaction. Please try again.'
      }));
      throw error;
    }
  };

  // Create a new voucher
  const createVoucher = async (
    data: Omit<ShoppingVoucher, 'id' | 'wallet_id' | 'created_at' | 'updated_at'>
  ): Promise<ShoppingVoucher> => {
    setWalletData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const newVoucher = await api.wallets.createShoppingVoucher(data);
      
      setWalletData(prev => ({
        ...prev,
        vouchers: [...prev.vouchers, newVoucher],
        loading: false
      }));
      
      return newVoucher;
    } catch (error) {
      console.error('Error creating voucher:', error);
      setWalletData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to create voucher. Please try again.'
      }));
      throw error;
    }
  };

  // Use a voucher
  const useVoucher = async (id: string): Promise<ShoppingVoucher> => {
    setWalletData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      // Mark voucher as used by updating it
      const updatedVoucher = await api.wallets.updateShoppingVoucher(id, { is_used: true });
      
      // Update wallet data after using voucher
      await fetchWalletData();
      
      return updatedVoucher;
    } catch (error) {
      console.error('Error using voucher:', error);
      setWalletData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to use voucher. Please try again.'
      }));
      throw error;
    }
  };

  // Fetch data when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchWalletData();
    } else {
      // Reset data when logged out
      setWalletData(initialWalletData);
    }
  }, [isAuthenticated]);

  return (
    <WalletContext.Provider 
      value={{
        walletData,
        fetchWalletData,
        createTransaction,
        createVoucher,
        useVoucher,
        totalIncomeBalance,
        totalShoppingBalance
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

// Custom hook for using the context
export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
