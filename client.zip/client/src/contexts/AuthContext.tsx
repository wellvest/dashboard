import React, { createContext, useState, useContext, useEffect } from 'react';
import { api } from '../utils/api';

// Define user type
export interface User {
  id: string;
  name: string;
  email?: string; // Email is now optional
  avatar?: string;
  member_id: string; // Changed from memberId to match backend
  phone: string; // Phone is now required
  date_of_birth?: string;
  gender?: string;
}

// Define profile type
export interface Profile {
  id: string;
  user_id: string;
  plan_amount: number;
  kyc_verified: boolean;
  kyc_document_type: string | null;
  kyc_document_number: string | null;
  kyc_document_url: string | null;
}

// Define context type
interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (phone: string, password: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  fetchUserProfile: () => Promise<void>;
}

// Create context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  logout: () => {},
  refreshUser: async () => {},
  fetchUserProfile: async () => {},
});

// Custom hook to use auth context
export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch current user data from API
  const fetchCurrentUser = async (): Promise<User | null> => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return null;
      
      const userData = await api.user.me();
      return userData;
    } catch (error) {
      console.error('Error fetching user data:', error);
      // Don't remove token on every error - only on 401 unauthorized
      if (error.response && error.response.status === 401) {
        localStorage.removeItem('token');
      }
      return null;
    }
  };

  // Fetch user profile data
  const fetchUserProfile = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      // Get complete profile data
      const profileResponse = await api.user.profile();
      if (profileResponse) {
        setUser(profileResponse.user);
        setProfile(profileResponse.profile);
      }
    } catch (error) {
      console.error('Failed to fetch user profile:', error);
    }
  };

  // Check if user is already logged in on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          setIsLoading(false);
          return;
        }
        
        const userData = await fetchCurrentUser();
        if (userData) {
          setUser(userData);
          // Also fetch profile data
          await fetchUserProfile();
        }
      } catch (error) {
        console.error('Error checking authentication:', error);
        // Only remove token on 401 unauthorized errors
        if (error.response && error.response.status === 401) {
          localStorage.removeItem('token');
        }
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Refresh user data
  const refreshUser = async () => {
    try {
      const userData = await fetchCurrentUser();
      if (userData) {
        setUser(userData);
      }
    } catch (error) {
      console.error('Error refreshing user data:', error);
    }
  };

  // Login function
  const login = async (phone: string, password: string) => {
    setIsLoading(true);
    try {
      // Call the login API endpoint
      const response = await api.auth.login({
        phone: phone, // API now expects phone field
        password: password
      });
      
      // Store the JWT token
      localStorage.setItem('token', response.access_token);
      
      // Fetch user data
      const userData = await api.user.me();
      setUser(userData);
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
        refreshUser,
        fetchUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
