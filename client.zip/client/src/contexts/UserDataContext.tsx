import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { api } from '../utils/api';

// Define types for our user data
interface UserAddress {
  id?: string;
  address_type: string;
  address_line1: string;
  address_line2?: string;
  city: string;
  state: string;
  zip_code: string;
  country: string;
  notes?: string;
  is_default: boolean;
}

interface BankDetail {
  id?: string;
  account_holder_name: string;
  account_number: string;
  bank_name: string;
  branch_name: string;
  ifsc_code: string;
  is_default: boolean;
}

interface UserProfile {
  id?: string;
  user_id?: string;
  plan_amount: number;
  kyc_verified: boolean;
  created_at?: string;
  updated_at?: string;
}

interface UserData {
  profile: UserProfile | null;
  addresses: UserAddress[];
  bankDetails: BankDetail[];
  loading: boolean;
  error: string | null;
}

interface UserDataContextType {
  userData: UserData;
  fetchUserData: () => Promise<void>;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
  addAddress: (data: Omit<UserAddress, 'id'>) => Promise<void>;
  updateAddress: (id: string, data: Partial<UserAddress>) => Promise<void>;
  addBankDetail: (data: Omit<BankDetail, 'id'>) => Promise<void>;
  updateBankDetail: (id: string, data: Partial<BankDetail>) => Promise<void>;
}

// Initial data
const initialUserData: UserData = {
  profile: null,
  addresses: [],
  bankDetails: [],
  loading: false,
  error: null
};

// Create the context
const UserDataContext = createContext<UserDataContextType | undefined>(undefined);

// Provider component
export function UserDataProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth();
  const [userData, setUserData] = useState<UserData>(initialUserData);

  // Fetch user data from API
  const fetchUserData = async () => {
    if (!isAuthenticated) return;
    
    setUserData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      // Fetch complete user profile with related data
      const profileData = await api.user.profile();
      
      setUserData({
        profile: profileData.profile || null,
        addresses: profileData.addresses || [],
        bankDetails: profileData.bank_details || [],
        loading: false,
        error: null
      });
    } catch (error) {
      console.error('Error fetching user data:', error);
      setUserData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to load user data. Please try again.'
      }));
    }
  };

  // Fetch data when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchUserData();
    } else {
      // Reset data when logged out
      setUserData(initialUserData);
    }
  }, [isAuthenticated]);

  // Update profile
  const updateProfile = async (data: Partial<UserProfile>) => {
    setUserData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const updatedProfile = await api.profile.update(data);
      
      setUserData(prev => ({
        ...prev,
        profile: updatedProfile,
        loading: false
      }));
    } catch (error) {
      console.error('Error updating profile:', error);
      setUserData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to update profile. Please try again.'
      }));
      throw error;
    }
  };

  // Add address
  const addAddress = async (data: Omit<UserAddress, 'id'>) => {
    setUserData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const newAddress = await api.profile.createAddress(data);
      
      setUserData(prev => ({
        ...prev,
        addresses: [...prev.addresses, newAddress],
        loading: false
      }));
    } catch (error) {
      console.error('Error adding address:', error);
      setUserData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to add address. Please try again.'
      }));
      throw error;
    }
  };

  // Update address
  const updateAddress = async (id: string, data: Partial<UserAddress>) => {
    setUserData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const updatedAddress = await api.profile.updateAddress(id, data);
      
      setUserData(prev => ({
        ...prev,
        addresses: prev.addresses.map(addr => 
          addr.id === id ? updatedAddress : addr
        ),
        loading: false
      }));
    } catch (error) {
      console.error('Error updating address:', error);
      setUserData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to update address. Please try again.'
      }));
      throw error;
    }
  };

  // Add bank detail
  const addBankDetail = async (data: Omit<BankDetail, 'id'>) => {
    setUserData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const newBankDetail = await api.profile.createBankDetail(data);
      
      setUserData(prev => ({
        ...prev,
        bankDetails: [...prev.bankDetails, newBankDetail],
        loading: false
      }));
    } catch (error) {
      console.error('Error adding bank detail:', error);
      setUserData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to add bank detail. Please try again.'
      }));
      throw error;
    }
  };

  // Update bank detail
  const updateBankDetail = async (id: string, data: Partial<BankDetail>) => {
    setUserData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const updatedBankDetail = await api.profile.updateBankDetail(id, data);
      
      setUserData(prev => ({
        ...prev,
        bankDetails: prev.bankDetails.map(bank => 
          bank.id === id ? updatedBankDetail : bank
        ),
        loading: false
      }));
    } catch (error) {
      console.error('Error updating bank detail:', error);
      setUserData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to update bank detail. Please try again.'
      }));
      throw error;
    }
  };

  return (
    <UserDataContext.Provider 
      value={{
        userData,
        fetchUserData,
        updateProfile,
        addAddress,
        updateAddress,
        addBankDetail,
        updateBankDetail
      }}
    >
      {children}
    </UserDataContext.Provider>
  );
}

// Custom hook for using the context
export function useUserData() {
  const context = useContext(UserDataContext);
  if (context === undefined) {
    throw new Error('useUserData must be used within a UserDataProvider');
  }
  return context;
}
