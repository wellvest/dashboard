import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { api } from '../utils/api';

// Define types for network data
interface NetworkMember {
  id: string;
  user_id: string;
  referrer_id: string;
  level: number;
  created_at: string;
  updated_at: string;
  user?: {
    name: string;
    email: string;
    member_id: string;
  };
}

interface Bonus {
  id: string;
  user_id: string;
  amount: number;
  bonus_type: string;
  description: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface NOC {
  id: string;
  user_id: string;
  code: string;
  is_used: boolean;
  used_by?: string;
  created_at: string;
  updated_at: string;
}

interface NetworkData {
  networkMembers: NetworkMember[];
  bonuses: Bonus[];
  nocs: NOC[];
  referralCode: string;
  loading: boolean;
  error: string | null;
}

interface NetworkContextType {
  networkData: NetworkData;
  fetchNetworkData: () => Promise<void>;
  joinNetwork: (referralCode: string) => Promise<void>;
  generateNOC: () => Promise<NOC>;
  totalBonusAmount: number;
  totalNetworkSize: number;
  activeNOCs: NOC[];
}

// Initial data
const initialNetworkData: NetworkData = {
  networkMembers: [],
  bonuses: [],
  nocs: [],
  referralCode: '',
  loading: false,
  error: null
};

// Create the context
const NetworkContext = createContext<NetworkContextType | undefined>(undefined);

// Provider component
export function NetworkProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated, user } = useAuth();
  const [networkData, setNetworkData] = useState<NetworkData>(initialNetworkData);

  // Calculate total bonus amount
  const totalBonusAmount = networkData.bonuses.reduce(
    (sum, bonus) => sum + bonus.amount, 
    0
  );

  // Calculate total network size
  const totalNetworkSize = networkData.networkMembers.length;

  // Get active NOCs
  const activeNOCs = networkData.nocs.filter(noc => !noc.is_used);

  // Fetch network data from API
  const fetchNetworkData = async () => {
    if (!isAuthenticated) return;
    
    setNetworkData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      // Fetch network data which includes members
      const networkData = await api.network.get();
      const networkMembers = networkData.members || [];
      
      // Fetch bonuses
      const bonuses = await api.network.getBonuses();
      
      // Fetch NOCs
      const nocs = await api.network.getNOCs();
      
      // Get referral code (member_id serves as referral code)
      const referralCode = user?.member_id || '';
      
      setNetworkData({
        networkMembers,
        bonuses,
        nocs,
        referralCode,
        loading: false,
        error: null
      });
    } catch (error) {
      console.error('Error fetching network data:', error);
      setNetworkData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to load network data. Please try again.'
      }));
    }
  };

  // Join network with referral code
  const joinNetwork = async (referralCode: string): Promise<void> => {
    setNetworkData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      await api.network.join(referralCode);
      
      // Refresh network data after joining
      await fetchNetworkData();
    } catch (error) {
      console.error('Error joining network:', error);
      setNetworkData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to join network. Please try again.'
      }));
      throw error;
    }
  };

  // Generate a new NOC
  const generateNOC = async (): Promise<NOC> => {
    setNetworkData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      // Create a new NOC with default values
      const newNOC = await api.network.createNOC({
        code: `NOC-${Date.now().toString().slice(-6)}`, // Generate a temporary code
        is_used: false
      });
      
      setNetworkData(prev => ({
        ...prev,
        nocs: [...prev.nocs, newNOC],
        loading: false
      }));
      
      return newNOC;
    } catch (error) {
      console.error('Error generating NOC:', error);
      setNetworkData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to generate NOC. Please try again.'
      }));
      throw error;
    }
  };

  // Fetch data when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchNetworkData();
    } else {
      // Reset data when logged out
      setNetworkData(initialNetworkData);
    }
  }, [isAuthenticated, user]);

  return (
    <NetworkContext.Provider 
      value={{
        networkData,
        fetchNetworkData,
        joinNetwork,
        generateNOC,
        totalBonusAmount,
        totalNetworkSize,
        activeNOCs
      }}
    >
      {children}
    </NetworkContext.Provider>
  );
}

// Custom hook for using the context
export function useNetwork() {
  const context = useContext(NetworkContext);
  if (context === undefined) {
    throw new Error('useNetwork must be used within a NetworkProvider');
  }
  return context;
}
