import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { api } from '../utils/api';

// Define types for investment data
interface Investment {
  id: string;
  user_id: string;
  amount: number;
  status: string;
  payment_method: string;
  transaction_id?: string;
  created_at: string;
  updated_at: string;
}

interface TeamInvestment {
  id: string;
  user_id: string;
  team_member_id: string;
  amount: number;
  status: string;
  created_at: string;
  updated_at: string;
  team_member?: {
    name: string;
    email: string;
    member_id: string;
  };
}

interface InvestmentData {
  investments: Investment[];
  teamInvestments: TeamInvestment[];
  loading: boolean;
  error: string | null;
}

interface InvestmentContextType {
  investmentData: InvestmentData;
  fetchInvestments: () => Promise<void>;
  createInvestment: (data: Omit<Investment, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Investment>;
  totalInvestment: number;
  totalTeamInvestment: number;
}

// Initial data
const initialInvestmentData: InvestmentData = {
  investments: [],
  teamInvestments: [],
  loading: false,
  error: null
};

// Create the context
const InvestmentContext = createContext<InvestmentContextType | undefined>(undefined);

// Provider component
export function InvestmentProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth();
  const [investmentData, setInvestmentData] = useState<InvestmentData>(initialInvestmentData);

  // Calculate total investment
  const totalInvestment = investmentData.investments.reduce(
    (sum, investment) => sum + investment.amount, 
    0
  );

  // Calculate total team investment
  const totalTeamInvestment = investmentData.teamInvestments.reduce(
    (sum, investment) => sum + investment.amount, 
    0
  );

  // Fetch investment data from API
  const fetchInvestments = async () => {
    if (!isAuthenticated) return;
    
    setInvestmentData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      // Fetch user investments
      const investments = await api.investments.getAll();
      
      // Fetch team investments
      const teamInvestments = await api.investments.getTeamInvestments();
      
      setInvestmentData({
        investments,
        teamInvestments,
        loading: false,
        error: null
      });
    } catch (error) {
      console.error('Error fetching investment data:', error);
      setInvestmentData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to load investment data. Please try again.'
      }));
    }
  };

  // Create a new investment
  const createInvestment = async (data: Omit<Investment, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<Investment> => {
    setInvestmentData(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const newInvestment = await api.investments.create(data);
      
      setInvestmentData(prev => ({
        ...prev,
        investments: [...prev.investments, newInvestment],
        loading: false
      }));
      
      return newInvestment;
    } catch (error) {
      console.error('Error creating investment:', error);
      setInvestmentData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to create investment. Please try again.'
      }));
      throw error;
    }
  };

  // Fetch data when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchInvestments();
    } else {
      // Reset data when logged out
      setInvestmentData(initialInvestmentData);
    }
  }, [isAuthenticated]);

  return (
    <InvestmentContext.Provider 
      value={{
        investmentData,
        fetchInvestments,
        createInvestment,
        totalInvestment,
        totalTeamInvestment
      }}
    >
      {children}
    </InvestmentContext.Provider>
  );
}

// Custom hook for using the context
export function useInvestment() {
  const context = useContext(InvestmentContext);
  if (context === undefined) {
    throw new Error('useInvestment must be used within an InvestmentProvider');
  }
  return context;
}
