import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { api } from "@/utils/api";
import { Share2, Copy, Check } from "lucide-react";

interface ReferralData {
  referral_code: string;
  referral_link: string;
}

export function ReferralCard() {
  const [referralData, setReferralData] = useState<ReferralData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const fetchReferralData = async () => {
      try {
        setIsLoading(true);
        const data = await api.referrals.getMyCode();
        setReferralData(data);
      } catch (error) {
        console.error("Failed to fetch referral data:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load your referral information",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchReferralData();
  }, [toast]);

  const handleCopyLink = () => {
    if (!referralData || !referralData.referral_code) return;
    
    // Create full URL with origin for copying
    const fullUrl = `${window.location.origin}${referralData.referral_link}`;
    
    navigator.clipboard.writeText(fullUrl)
      .then(() => {
        setCopied(true);
        toast({
          title: "Link copied!",
          description: "Referral link copied to clipboard",
        });
        
        // Reset copied state after 3 seconds
        setTimeout(() => setCopied(false), 3000);
      })
      .catch((error) => {
        console.error("Failed to copy link:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to copy link to clipboard",
        });
      });
  };

  const handleShare = async () => {
    if (!referralData || !referralData.referral_code) return;
    
    // Create full URL with origin for sharing
    const fullUrl = `${window.location.origin}${referralData.referral_link}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Join WellVest with my referral",
          text: "Sign up for WellVest using my referral link!",
          url: fullUrl,
        });
        
        toast({
          title: "Shared successfully!",
          description: "Your referral link has been shared",
        });
      } catch (error) {
        console.error("Error sharing:", error);
      }
    } else {
      // Fallback to copy if Web Share API is not available
      handleCopyLink();
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Invite Friends</CardTitle>
        <CardDescription>
          Share your referral link with friends and earn rewards when they join
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : referralData ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Your Referral Code</label>
              <div className="bg-muted p-3 rounded-md font-mono text-center text-lg">
                {referralData.referral_code}
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Your Referral Link</label>
              <div className="flex space-x-2">
                <Input 
                  value={referralData.referral_code ? `${window.location.origin}${referralData.referral_link}` : 'No referral link available'} 
                  readOnly 
                  className="font-mono text-sm"
                />
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={handleCopyLink}
                  disabled={!referralData.referral_code}
                  title="Copy to clipboard"
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            
            <Button 
              className="w-full" 
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-4 w-4" /> Share Referral Link
            </Button>
          </div>
        ) : (
          <div className="text-center py-4 text-muted-foreground">
            Unable to load referral information
          </div>
        )}
      </CardContent>
    </Card>
  );
}
