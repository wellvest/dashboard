import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, X, Check, Clock, Info, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { api } from "@/utils/api";
import { Notification } from "@/types/notification";
import { format, formatDistanceToNow } from "date-fns";

// Helper function to format notification time
const formatNotificationTime = (dateString: string): string => {
  try {
    const date = new Date(dateString);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return formatDistanceToNow(date, { addSuffix: true });
    } else if (now.getTime() - date.getTime() < 7 * 24 * 60 * 60 * 1000) {
      // Less than a week ago
      return formatDistanceToNow(date, { addSuffix: true });
    } else {
      return format(date, 'MMM d, yyyy');
    }
  } catch (e) {
    return 'Unknown time';
  }
};

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onNotificationsUpdate?: (unreadCount: number) => void;
}

export function NotificationPanel({ isOpen, onClose, onNotificationsUpdate }: NotificationPanelProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("all");
  
  const unreadCount = notifications.filter(n => !n.read).length;
  
  const filteredNotifications = activeTab === "all" 
    ? notifications 
    : notifications.filter(n => !n.read);

  // Fetch notifications when panel opens
  useEffect(() => {
    if (isOpen) {
      fetchNotifications();
    }
  }, [isOpen]);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.notifications.getAll();
      setNotifications(data);
      
      // Update unread count in parent component
      const newUnreadCount = data.filter(n => !n.read).length;
      if (onNotificationsUpdate) {
        onNotificationsUpdate(newUnreadCount);
      }
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
      setError('Failed to load notifications');
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (id: string) => {
    try {
      await api.notifications.markAsRead(id);
      setNotifications(prev => {
        const updated = prev.map(notification => 
          notification.id === id 
            ? { ...notification, read: true } 
            : notification
        );
        
        // Update unread count in parent component
        const newUnreadCount = updated.filter(n => !n.read).length;
        if (onNotificationsUpdate) {
          onNotificationsUpdate(newUnreadCount);
        }
        
        return updated;
      });
    } catch (err) {
      console.error('Failed to mark notification as read:', err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await api.notifications.markAllAsRead();
      setNotifications(prev => {
        const updated = prev.map(notification => ({ ...notification, read: true }));
        
        // Update unread count in parent component
        if (onNotificationsUpdate) {
          onNotificationsUpdate(0);
        }
        
        return updated;
      });
    } catch (err) {
      console.error('Failed to mark all notifications as read:', err);
    }
  };
  
  const deleteNotification = async (id: string) => {
    try {
      await api.notifications.delete(id);
      setNotifications(prev => {
        const updated = prev.filter(notification => notification.id !== id);
        
        // Update unread count in parent component if the deleted notification was unread
        const deletedNotification = prev.find(n => n.id === id);
        if (deletedNotification && !deletedNotification.read && onNotificationsUpdate) {
          const newUnreadCount = updated.filter(n => !n.read).length;
          onNotificationsUpdate(newUnreadCount);
        }
        
        return updated;
      });
    } catch (err) {
      console.error('Failed to delete notification:', err);
    }
  };

  // Close on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isOpen, onClose]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "success":
        return <Check className="h-5 w-5 text-green-500" />;
      case "warning":
        return <AlertCircle className="h-5 w-5 text-amber-500" />;
      case "info":
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/20 z-40"
            onClick={onClose}
          />
          
          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.95 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="fixed right-4 top-16 w-full max-w-sm bg-card border border-border shadow-lg rounded-lg z-50"
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center">
                <Bell className="h-5 w-5 mr-2 text-primary" />
                <h2 className="font-semibold text-lg">Notifications</h2>
                {unreadCount > 0 && (
                  <motion.span
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="ml-2 px-2 py-0.5 text-xs font-medium bg-primary text-primary-foreground rounded-full"
                  >
                    {unreadCount} new
                  </motion.span>
                )}
              </div>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
              <div className="flex items-center justify-between px-4 py-2 border-b border-border">
                <TabsList className="grid w-[200px] grid-cols-2">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="unread">Unread</TabsTrigger>
                </TabsList>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={markAllAsRead}
                  disabled={unreadCount === 0}
                  className="text-xs"
                >
                  Mark all read
                </Button>
              </div>
              
              {loading ? (
                <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
                  <Loader2 className="h-8 w-8 text-primary animate-spin mb-3" />
                  <p className="text-muted-foreground">Loading notifications...</p>
                </div>
              ) : error ? (
                <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
                  <AlertCircle className="h-8 w-8 text-destructive mb-3" />
                  <p className="text-muted-foreground">{error}</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-4" 
                    onClick={fetchNotifications}
                  >
                    Try Again
                  </Button>
                </div>
              ) : (
                <>
                  <TabsContent value="all" className="mt-0 pt-0">
                    <NotificationList 
                      notifications={filteredNotifications} 
                      onMarkAsRead={markAsRead}
                      onDelete={deleteNotification}
                      getIcon={getNotificationIcon}
                    />
                  </TabsContent>
                  
                  <TabsContent value="unread" className="mt-0 pt-0">
                    <NotificationList 
                      notifications={filteredNotifications} 
                      onMarkAsRead={markAsRead}
                      onDelete={deleteNotification}
                      getIcon={getNotificationIcon}
                    />
                  </TabsContent>
                </>
              )}
            </Tabs>
            
            <div className="p-3 border-t border-border">
              <Button 
                variant="outline" 
                className="w-full text-sm" 
                size="sm"
                onClick={() => {
                  setActiveTab("all");
                  // Scroll to top if needed
                  const scrollArea = document.querySelector('.h-\\[350px\\]');
                  if (scrollArea) {
                    scrollArea.scrollTop = 0;
                  }
                }}
              >
                View all notifications
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

interface NotificationListProps {
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onDelete: (id: string) => void;
  getIcon: (type: string) => JSX.Element;
}

function NotificationList({ notifications, onMarkAsRead, onDelete, getIcon }: NotificationListProps) {
  if (notifications.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
        <Bell className="h-10 w-10 text-muted-foreground mb-3 opacity-40" />
        <p className="text-muted-foreground">No notifications to display</p>
      </div>
    );
  }
  
  return (
    <ScrollArea className="h-[350px]">
      <div className="divide-y divide-border">
        {notifications.map((notification, index) => (
          <motion.div
            key={notification.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05, duration: 0.2 }}
            className={cn(
              "p-4 hover:bg-muted/50 transition-colors",
              !notification.read && "bg-muted/30"
            )}
          >
            <div className="flex items-start gap-3">
              <div className="p-1.5 rounded-full bg-muted">
                {getIcon(notification.type)}
              </div>
              
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className={cn(
                    "text-sm font-medium",
                    !notification.read && "font-semibold"
                  )}>
                    {notification.title}
                  </h4>
                  <div className="flex items-center space-x-1">
                    {!notification.read && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 w-6 p-0" 
                        onClick={() => onMarkAsRead(notification.id)}
                      >
                        <span className="sr-only">Mark as read</span>
                        <Check className="h-3 w-3" />
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive" 
                      onClick={() => onDelete(notification.id)}
                    >
                      <span className="sr-only">Delete</span>
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {notification.message}
                </p>
                <div className="flex items-center mt-2 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 mr-1" />
                  {formatNotificationTime(notification.created_at)}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </ScrollArea>
  );
}
