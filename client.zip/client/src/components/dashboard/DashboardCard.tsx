import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface DashboardCardProps {
  title: string;
  icon: LucideIcon;
  onClick?: () => void;
  variant?: "default" | "new" | "coming-soon";
  className?: string;
}

export function DashboardCard({ 
  title, 
  icon: Icon, 
  onClick, 
  variant = "default",
  className 
}: DashboardCardProps) {
  return (
    <Card 
      className={cn(
        "relative cursor-pointer transition-all duration-200 hover:shadow-hover hover:-translate-y-1",
        "bg-white border border-gray-100/80 shadow-card overflow-hidden",
        className
      )}
      onClick={onClick}
    >
      <div className="absolute inset-0 bg-gradient-card opacity-70"></div>
      <div className="absolute top-0 left-0 w-1.5 h-full bg-primary"></div>
      <CardContent className="p-6 text-center relative z-10">
        <div className="flex flex-col items-center space-y-4">
          <div className="p-3 rounded-full bg-gradient-primary/10 ring-4 ring-primary/5">
            <Icon className="h-8 w-8 text-primary" />
          </div>
          <div className="flex items-center space-x-2">
            <h3 className="font-semibold text-navy-header">{title}</h3>
            {variant === "new" && (
              <span className="px-2 py-0.5 text-xs bg-accent/10 text-accent rounded-full font-medium border border-accent/20">
                New!
              </span>
            )}
            {variant === "coming-soon" && (
              <span className="px-2 py-0.5 text-xs bg-amber-100 text-amber-600 rounded-full font-medium border border-amber-200">
                Coming Soon
              </span>
            )}
          </div>
        </div>
        
        {variant === "new" && (
          <div className="absolute top-2 right-2">
            <div className="w-2 h-2 bg-accent animate-pulse rounded-full ring-2 ring-accent/20"></div>
          </div>
        )}
        {variant === "coming-soon" && (
          <div className="absolute top-2 right-2">
            <div className="w-2 h-2 bg-amber-500 animate-pulse rounded-full ring-2 ring-amber-200"></div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}