import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, AlertCircle, ChevronRight } from "lucide-react";
import { useUserData } from "@/contexts/UserDataContext";

interface CompletionItemProps {
  title: string;
  isComplete: boolean;
  path: string;
}

const CompletionItem = ({ title, isComplete, path }: CompletionItemProps) => {
  const navigate = useNavigate();
  
  return (
    <div className="flex items-center justify-between p-3 border-b last:border-0">
      <div className="flex items-center gap-3">
        {isComplete ? (
          <CheckCircle2 className="h-5 w-5 text-success" />
        ) : (
          <AlertCircle className="h-5 w-5 text-destructive" />
        )}
        <span className="font-medium">{title}</span>
      </div>
      {!isComplete && (
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-primary"
          onClick={() => navigate(path)}
        >
          Complete <ChevronRight className="h-4 w-4 ml-1" />
        </Button>
      )}
    </div>
  );
};

export function ProfileCompletionStatus() {
  const { userData } = useUserData();
  
  // Check completion status
  const isProfileComplete = !!(userData.profile && userData.profile.kyc_verified);
  const isAddressComplete = !!(userData.addresses && userData.addresses.length > 0);
  const isBankDetailsComplete = !!(userData.bankDetails && userData.bankDetails.length > 0);
  
  // Calculate completion percentage
  const totalItems = 3;
  const completedItems = [isProfileComplete, isAddressComplete, isBankDetailsComplete].filter(Boolean).length;
  const completionPercentage = Math.round((completedItems / totalItems) * 100);
  
  return (
    <Card className="shadow-card border border-gray-100/80 bg-gradient-card">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-lg">Profile Completion</h3>
          <span className="text-sm font-medium bg-primary/10 text-primary px-2 py-1 rounded-full">
            {completionPercentage}% Complete
          </span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2 mb-5">
          <div 
            className="bg-primary h-2 rounded-full" 
            style={{ width: `${completionPercentage}%` }}
          ></div>
        </div>
        
        <div className="space-y-1">
          <CompletionItem 
            title="KYC Verification" 
            isComplete={isProfileComplete} 
            path="/profile" 
          />
          <CompletionItem 
            title="Address Details" 
            isComplete={isAddressComplete} 
            path="/profile/address" 
          />
          <CompletionItem 
            title="Bank Account" 
            isComplete={isBankDetailsComplete} 
            path="/profile/bank" 
          />
        </div>
      </CardContent>
    </Card>
  );
}
