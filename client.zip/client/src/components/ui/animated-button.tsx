import React from "react";
import { motion } from "framer-motion";
import { Button, ButtonProps } from "./button";

interface AnimatedButtonProps extends ButtonProps {
  animation?: "hover" | "tap" | "both";
}

export function AnimatedButton({ 
  children, 
  animation = "both", 
  ...props 
}: React.PropsWithChildren<AnimatedButtonProps>) {
  const motionProps = {
    ...(animation === "hover" || animation === "both" ? {
      whileHover: { scale: 1.03 }
    } : {}),
    ...(animation === "tap" || animation === "both" ? {
      whileTap: { scale: 0.97 }
    } : {})
  };

  return (
    <motion.div {...motionProps} className="inline-block">
      <Button {...props}>
        {children}
      </Button>
    </motion.div>
  );
}
