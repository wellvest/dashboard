import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Upload, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/utils/api";
import { useAuth, User } from "@/contexts/AuthContext";

interface AvatarUploadProps {
  currentAvatarUrl?: string | null;
  userName: string;
  onAvatarUpdate?: (newAvatarUrl: string) => void;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  editable?: boolean;
}

export function AvatarUpload({
  currentAvatarUrl,
  userName,
  onAvatarUpdate,
  size = "md",
  className = "",
  editable = true,
}: AvatarUploadProps) {
  const { refreshUser } = useAuth();
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  // Get initials from user name
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  // Size classes
  const sizeClasses = {
    sm: "h-10 w-10",
    md: "h-16 w-16",
    lg: "h-24 w-24",
    xl: "h-32 w-32",
  };

  // Handle file selection
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ["image/jpeg", "image/png", "image/gif", "image/jpg"];
    if (!validTypes.includes(file.type)) {
      toast.error("Please select a valid image file (JPEG, PNG, or GIF)");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size should be less than 5MB");
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Upload file
    try {
      setIsUploading(true);
      const formData = new FormData();
      formData.append("avatar_file", file);

      // Cast the response to User type to access the avatar property
      const response = await api.user.uploadAvatar(formData) as User;

      if (response && response.avatar) {
        toast.success("Profile picture updated successfully");
        if (onAvatarUpdate) {
          onAvatarUpdate(response.avatar);
        }
        // Refresh user data in auth context
        refreshUser();
      }
    } catch (error) {
      console.error("Error uploading avatar:", error);
      toast.error("Failed to upload profile picture");
      // Reset preview on error
      setPreviewUrl(null);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className={`relative group ${className}`}>
      <Avatar className={`${sizeClasses[size]} border-2 border-border`}>
        <AvatarImage 
          src={previewUrl || (currentAvatarUrl || "")} 
          alt={userName} 
        />
        <AvatarFallback>{getInitials(userName)}</AvatarFallback>
      </Avatar>
      
      {editable && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
          <label 
            htmlFor="avatar-upload" 
            className="cursor-pointer flex items-center justify-center w-full h-full"
          >
            {isUploading ? (
              <Loader2 className="h-5 w-5 text-white animate-spin" />
            ) : (
              <Upload className="h-5 w-5 text-white" />
            )}
          </label>
          <input
            id="avatar-upload"
            type="file"
            accept="image/jpeg,image/png,image/gif"
            className="hidden"
            onChange={handleFileChange}
            disabled={isUploading}
          />
        </div>
      )}
    </div>
  );
}
