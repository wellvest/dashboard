import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { X } from "lucide-react";
import { NetworkTreeView } from "./network-tree-view";

interface NetworkNode {
  id: string;
  name: string;
  level: number;
  status: string;
  business: string;
  children?: NetworkNode[];
}

interface NetworkTreeModalProps {
  isOpen: boolean;
  onClose: () => void;
  rootNode: NetworkNode;
}



export function NetworkTreeModal({ isOpen, onClose, rootNode }: NetworkTreeModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[90vw] max-h-[90vh] overflow-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle>Network Tree</DialogTitle>
          <button 
            onClick={onClose}
            className="rounded-full p-1 hover:bg-muted transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </DialogHeader>
        
        <div className="py-4 overflow-x-auto">
          <NetworkTreeView rootNode={rootNode} />
        </div>
      </DialogContent>
    </Dialog>
  );
}
