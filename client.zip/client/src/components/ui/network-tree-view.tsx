import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface NetworkNode {
  id: string;
  name: string;
  level: number;
  status: string;
  business?: string;
  children?: NetworkNode[];
}

interface NetworkTreeViewProps {
  rootNode: NetworkNode;
}

const NetworkNodeComponent: React.FC<{ node: NetworkNode; isRoot?: boolean }> = ({ node, isRoot = false }) => {
  const statusColors = {
    "Active": "bg-green-500",
    "InActive": "bg-red-500",
    "Blocked": "bg-yellow-500"
  };

  return (
    <div className="flex flex-col items-center">
      {/* Node content */}
      <div className="flex flex-col items-center">
        <Avatar className="h-16 w-16 border-2 border-primary">
          <AvatarImage src={`/avatars/${node.id}.jpg`} alt={node.name} />
          <AvatarFallback className="bg-primary/10 text-primary text-lg">
            {node.name.split(' ').map(n => n[0]).join('')}
          </AvatarFallback>
        </Avatar>
        <div className="mt-2 text-center">
          <div className="text-xs font-medium text-muted-foreground">{node.id}</div>
          <div className="font-semibold">{node.name}</div>
          <Badge variant="outline" className={`mt-1 ${statusColors[node.status as keyof typeof statusColors]} text-white`}>
            {node.status}
          </Badge>
        </div>
      </div>

      {/* Children */}
      {node.children && node.children.length > 0 && (
        <>
          {/* Vertical line connecting to horizontal line */}
          <div className="w-px h-12 bg-gray-300 mt-2"></div>
          
          {/* Horizontal line connecting children */}
          <div className="relative">
            {node.children.length > 1 && (
              <div 
                className="absolute top-0 left-1/2 transform -translate-x-1/2" 
                style={{
                  width: `${(node.children.length - 1) * 200}px`,
                  height: '1px',
                  backgroundColor: '#d1d5db'
                }}
              ></div>
            )}
            
            {/* Children container */}
            <div className="flex justify-center" style={{ gap: '200px' }}>
              {node.children.map((child, index) => (
                <div key={child.id} className="flex flex-col items-center">
                  {/* Vertical line to child */}
                  <div className="w-px h-12 bg-gray-300 -mt-12"></div>
                  <NetworkNodeComponent node={child} />
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export function NetworkTreeView({ rootNode }: NetworkTreeViewProps) {
  return (
    <div className="w-full overflow-auto p-8" style={{ minWidth: '800px' }}>
      <div className="flex justify-center">
        <NetworkNodeComponent node={rootNode} isRoot={true} />
      </div>
    </div>
  );
}
