import React from "react";
import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  variant?: "full" | "icon";
}

export function Logo({ className, size = "md", variant = "full" }: LogoProps) {
  const sizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-2xl",
  };

  if (variant === "icon") {
    return (
      <div className={cn("font-bold text-orange-brand", sizeClasses[size], className)}>
        <span className="flex items-center justify-center">
          <svg 
            width="24" 
            height="24" 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
            className={cn("h-auto", {
              "w-6": size === "sm",
              "w-8": size === "md",
              "w-10": size === "lg",
            })}
          >
            <path 
              d="M12 2L4 6V18L12 22L20 18V6L12 2Z" 
              stroke="currentColor" 
              strokeWidth="2" 
              fill="rgba(255,107,0,0.2)" 
            />
            <path 
              d="M17 8.5L10 15.5L7 12.5" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
            />
          </svg>
        </span>
      </div>
    );
  }

  return (
    <div className={cn("font-bold text-orange-brand flex items-center", sizeClasses[size], className)}>
      <svg 
        width="24" 
        height="24" 
        viewBox="0 0 24 24" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="mr-2"
      >
        <path 
          d="M12 2L4 6V18L12 22L20 18V6L12 2Z" 
          stroke="currentColor" 
          strokeWidth="2" 
          fill="rgba(255,107,0,0.2)" 
        />
        <path 
          d="M17 8.5L10 15.5L7 12.5" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
        />
      </svg>
      <span>WellVest</span>
    </div>
  );
}
