import { useState, useEffect } from "react";
import { Bell, User, LogOut, Settings, MapPin, ShieldCheck, Lock } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { AnimatedButton } from "@/components/ui/animated-button";
import { NotificationPanel } from "@/components/notifications/NotificationPanel";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { useUserData } from "@/contexts/UserDataContext";
import { api } from "@/utils/api";

export function AppHeader() {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [loading, setLoading] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { userData } = useUserData();
  
  // Fetch unread notification count on component mount
  useEffect(() => {
    fetchUnreadCount();
  }, []);
  
  const fetchUnreadCount = async () => {
    try {
      setLoading(true);
      const count = await api.notifications.getUnreadCount();
      setUnreadNotifications(count);
    } catch (err) {
      console.error('Failed to fetch unread notification count:', err);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <header className="h-16 border-b border-border bg-card px-6 flex items-center justify-between">
      {/* Address Info */}
      {userData.addresses && userData.addresses.length > 0 ? (
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center space-x-2 text-sm"
        >
          <MapPin className="h-4 w-4 text-muted-foreground" />
          <Link to="/profile/address" className="text-muted-foreground hover:text-foreground transition-colors">
            <span className="hidden sm:inline">
              {userData.addresses[0].address_line1}, {userData.addresses[0].city}, {userData.addresses[0].state}
            </span>
            <span className="sm:hidden">
              {userData.addresses[0].city}, {userData.addresses[0].state.substring(0, 2)}
            </span>
          </Link>
          <Badge variant="outline" className="ml-2 text-xs py-0 px-1.5 hidden sm:flex">
            <Link to="/profile/address" className="hover:text-primary">Update</Link>
          </Badge>
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center space-x-2 text-sm"
        >
          <Link to="/profile/address" className="text-muted-foreground hover:text-foreground transition-colors flex items-center">
            <MapPin className="h-4 w-4 mr-1" />
            <span>Add Address</span>
          </Link>
        </motion.div>
      )}
      
      <div className="flex items-center space-x-4">
        {/* Notifications */}
        <AnimatedButton 
          variant="ghost" 
          size="icon" 
          className="relative" 
          onClick={() => setNotificationsOpen(!notificationsOpen)}
        >
          <Bell className="h-5 w-5" />
          {unreadNotifications > 0 && (
            <motion.span 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 rounded-full flex items-center justify-center text-[10px] text-white font-medium"
            >
              {unreadNotifications}
            </motion.span>
          )}
        </AnimatedButton>
        
        <NotificationPanel 
          isOpen={notificationsOpen} 
          onClose={() => setNotificationsOpen(false)}
          onNotificationsUpdate={(count) => setUnreadNotifications(count)}
        />

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <div className="flex items-center space-x-3 cursor-pointer hover:bg-muted p-2 rounded-lg transition-colors">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.avatar || "/api/placeholder/32/32"} alt={user?.name || "User"} />
                <AvatarFallback>{user?.name?.split(" ").map(n => n[0]).join("") || "U"}</AvatarFallback>
              </Avatar>
              <div className="text-sm">
                <div className="font-medium">{user?.name || "User"}</div>
                <div className="text-muted-foreground">{user?.member_id || ""}</div>
              </div>
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/profile")}>
              <User className="mr-2 h-4 w-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/reset-password")}>
              <Lock className="mr-2 h-4 w-4" />
              Reset Password
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/profile/address")}>
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </DropdownMenuItem>
            
            {/* Admin Panel Link - Only visible to admin users */}
            {user?.email?.endsWith('@admin.wellvest.com') && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("/admin")}>
                  <ShieldCheck className="mr-2 h-4 w-4 text-primary" />
                  Admin Panel
                </DropdownMenuItem>
              </>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              className="text-red-600"
              onClick={() => {
                logout();
                toast({
                  title: "Logged out",
                  description: "You have been successfully logged out."
                });
                navigate("/login");
              }}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}