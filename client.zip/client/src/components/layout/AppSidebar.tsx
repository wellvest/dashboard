import { NavLink, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  User, 
  Users, 
  Network, 
  ShoppingBag, 
  FileText, 
  Gift, 
  Wallet, 
  Target,
  Menu,
  ChevronDown,
  ChevronRight,
  UserCircle,
  MapPin,
  CreditCard,
  FileCheck,
  BarChart,
  UsersRound,
  Lock
} from "lucide-react";
import { Logo } from "@/components/ui/logo";
import { useState, useRef } from "react";
import { cn } from "@/lib/utils";

const menuItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { 
    title: "Profile", 
    url: "/profile", 
    icon: User,
    hasSubmenu: true,
    submenu: [
      { title: "My Profile", url: "/profile", icon: UserCircle },
      { title: "Address", url: "/profile/address", icon: MapPin },
      { title: "Bank Details", url: "/profile/bank", icon: CreditCard },
      { title: "KYC", url: "/profile/kyc", icon: FileCheck }
    ]
  },
  { title: "My Achievers Group", url: "/achievers", icon: Users },
  { title: "My Network", url: "/network", icon: Network },
  { title: "Shopping Voucher", url: "/shopping-voucher", icon: ShoppingBag },
  { title: "NOC", url: "/noc", icon: FileText },
  { title: "My profit", url: "/bonus", icon: Gift },
  { title: "Income Wallet", url: "/income-wallet", icon: Wallet },
  { 
    title: "Plan", 
    url: "/plan", 
    icon: Target,
    hasSubmenu: true,
    submenu: [
      { title: "My Plan", url: "/plan", icon: BarChart },
      { title: "My Team Plan", url: "/plan/team", icon: UsersRound }
    ]
  }
];

interface AppSidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

export function AppSidebar({ isCollapsed, onToggle }: AppSidebarProps) {
  const location = useLocation();
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);

  const toggleSubmenu = (title: string) => {
    setExpandedMenus(prev => 
      prev.includes(title) 
        ? prev.filter(item => item !== title)
        : [...prev, title]
    );
  };

  const isActive = (url: string) => {
    if (url === "/") return location.pathname === "/";
    return location.pathname.startsWith(url);
  };

  const isSubmenuExpanded = (title: string) => expandedMenus.includes(title);

  return (
    <div className={cn(
      "h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300 relative",
      isCollapsed ? "w-16" : "w-64"
    )}>
      {/* Header */}
      <div className={cn(
        "flex items-center border-b border-sidebar-border",
        isCollapsed ? "p-3 justify-center" : "p-4 justify-between"
      )}>
        <div onClick={isCollapsed ? onToggle : undefined} className={isCollapsed ? "cursor-pointer" : ""}>
          {!isCollapsed ? (
            <Logo size="md" variant="full" />
          ) : (
            <Logo size="sm" variant="icon" />
          )}
        </div>
        {!isCollapsed && (
          <button
            onClick={onToggle}
            className="p-2 rounded-lg hover:bg-sidebar-hover transition-colors flex-shrink-0"
            aria-label="Toggle sidebar"
          >
            <Menu className="h-5 w-5 text-sidebar-text" />
          </button>
        )}
      </div>

      {/* Navigation */}
      <nav className="p-3">
        {!isCollapsed && (
          <div className="text-xs text-sidebar-text mb-3 px-3 font-medium">
            Main Menu
          </div>
        )}
        
        <div className="space-y-1">
          {menuItems.map((item) => (
            <div key={item.title}>
              {/* Main Menu Item */}
              <div className="relative">
                {item.hasSubmenu ? (
                  <button
                    onClick={() => toggleSubmenu(item.title)}
                    className={cn(
                      "w-full flex items-center px-3 py-2.5 rounded-lg transition-all duration-200 group",
                      isActive(item.url)
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-sidebar-text hover:bg-sidebar-hover hover:text-sidebar-text-active"
                    )}
                  >
                    <item.icon className="h-5 w-5 flex-shrink-0" />
                    {!isCollapsed && (
                      <>
                        <span className="ml-3 flex-1 text-left">{item.title}</span>
                        {isSubmenuExpanded(item.title) ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </>
                    )}
                  </button>
                ) : (
                  <NavLink
                    to={item.url}
                    className={({ isActive: isNavActive }) => cn(
                      "flex items-center px-3 py-2.5 rounded-lg transition-all duration-200 group",
                      isNavActive
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-sidebar-text hover:bg-sidebar-hover hover:text-sidebar-text-active"
                    )}
                  >
                    <item.icon className="h-5 w-5 flex-shrink-0" />
                    {!isCollapsed && (
                      <span className="ml-3">{item.title}</span>
                    )}
                  </NavLink>
                )}
              </div>

              {/* Submenu - Works for both collapsed and expanded states */}
              {item.hasSubmenu && isSubmenuExpanded(item.title) && (
                <div className={cn(
                  "mt-1 space-y-1",
                  isCollapsed ? "border-l-2 border-primary/30 ml-3 pl-2" : "ml-6"
                )}>
                  {item.submenu?.map((subItem) => (
                    <NavLink
                      key={subItem.title}
                      to={subItem.url}
                      className={({ isActive: isNavActive }) => cn(
                        "flex items-center rounded-lg text-sm transition-all duration-200",
                        isCollapsed 
                          ? "justify-center py-2" 
                          : "px-3 py-2",
                        isNavActive
                          ? "bg-primary/10 text-primary font-medium"
                          : "text-sidebar-text hover:bg-sidebar-hover hover:text-sidebar-text-active"
                      )}
                      title={isCollapsed ? subItem.title : undefined}
                    >
                      {isCollapsed ? (
                        <div className="w-5 h-5 flex items-center justify-center">
                          {subItem.icon ? <subItem.icon className="h-4 w-4" /> : <div className="text-xs font-bold">{subItem.title.charAt(0)}</div>}
                        </div>
                      ) : (
                        <>
                          {subItem.title}
                          {subItem.title === "My Team Plan" && (
                            <span className="ml-2 px-1.5 py-0.5 text-xs bg-red-100 text-red-600 rounded-full font-medium">
                              New!
                            </span>
                          )}
                        </>
                      )}
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </nav>
    </div>
  );
}