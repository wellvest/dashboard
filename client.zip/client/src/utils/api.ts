/**
 * API client utility for making authenticated requests to the backend
 */

// API base URL - update this to match your backend URL
const API_BASE_URL = '/api';

// Types
interface ApiRequestOptions extends RequestInit {
  params?: Record<string, string>;
  requiresAuth?: boolean;
}

interface ApiError extends Error {
  status?: number;
  data?: any;
}

/**
 * Make an API request with authentication and error handling
 */
export const apiRequest = async <T>(
  endpoint: string,
  options: ApiRequestOptions = {}
): Promise<T> => {
  const {
    params,
    requiresAuth = true,
    headers: customHeaders = {},
    ...otherOptions
  } = options;

  // Build URL with query parameters
  const url = new URL(`${API_BASE_URL}${endpoint}`);
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      url.searchParams.append(key, value);
    });
  }

  // Prepare headers
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...customHeaders,
  };

  // Add authorization token if required
  if (requiresAuth) {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Authentication required. Please login.');
    }
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(url.toString(), {
      ...otherOptions,
      headers,
    });

    // Handle HTTP errors
    if (!response.ok) {
      const error: ApiError = new Error(
        `API error: ${response.status} ${response.statusText}`
      );
      error.status = response.status;

      // Try to parse error response
      try {
        error.data = await response.json();
      } catch (e) {
        // If parsing fails, use status text
        error.data = { detail: response.statusText };
      }

      // Handle authentication errors
      if (response.status === 401) {
        localStorage.removeItem('token');
        // You might want to redirect to login or trigger a global auth state update
        console.error('Authentication failed. Please login again.');
      }

      throw error;
    }

    // Parse JSON response (or return empty object if no content)
    if (response.status !== 204) {
      return await response.json();
    }
    return {} as T;
  } catch (error) {
    if ((error as ApiError).status) {
      // This is an HTTP error that we've already processed
      throw error;
    }
    // This is a network error
    const networkError: ApiError = new Error('Network error. Please check your connection.');
    networkError.data = { detail: 'Failed to connect to the server' };
    throw networkError;
  }
};

/**
 * Make a file upload request with authentication
 */
export const apiUploadRequest = async <T>(
  endpoint: string,
  formData: FormData,
  options: ApiRequestOptions = {}
): Promise<T> => {
  const {
    requiresAuth = true,
    headers: customHeaders = {},
    ...otherOptions
  } = options;

  const url = new URL(`${API_BASE_URL}${endpoint}`);
  
  // Prepare headers
  const headers: HeadersInit = {
    ...customHeaders,
  };

  // Add authorization token if required
  if (requiresAuth) {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('Authentication required. Please login.');
    }
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Use the provided FormData directly

  try {
    const response = await fetch(url.toString(), {
      method: 'POST',
      headers,
      body: formData,
      ...otherOptions,
    });

    // Handle HTTP errors
    if (!response.ok) {
      const error: ApiError = new Error(
        `API error: ${response.status} ${response.statusText}`
      );
      error.status = response.status;

      // Try to parse error response
      try {
        error.data = await response.json();
      } catch (e) {
        // If parsing fails, use status text
        error.data = { detail: response.statusText };
      }

      throw error;
    }

    // Parse JSON response (or return empty object if no content)
    if (response.status !== 204) {
      return await response.json();
    }
    return {} as T;
  } catch (error) {
    if ((error as ApiError).status) {
      // This is an HTTP error that we've already processed
      throw error;
    }
    // This is a network error
    const networkError: ApiError = new Error('Network error. Please check your connection.');
    networkError.data = { detail: 'Failed to connect to the server' };
    throw networkError;
  }
};

/**
 * API client with methods for common operations
 */
export const api = {
  // Notification endpoints
  notifications: {
    getAll: () => apiRequest<any[]>('/notifications', { method: 'GET' }),
    getUnreadCount: () => apiRequest<number>('/notifications/unread-count', { method: 'GET' }),
    markAsRead: (notificationId: string) => apiRequest<any>(`/notifications/${notificationId}/read`, { 
      method: 'PATCH'
    }),
    markAllAsRead: () => apiRequest<number>('/notifications/mark-all-read', { method: 'PATCH' }),
    delete: (notificationId: string) => apiRequest<void>(`/notifications/${notificationId}`, { 
      method: 'DELETE'
    }),
  },
  
  // Bonus endpoints
  bonus: {
    getBonusSummary: () => apiRequest<any>('/bonus/summary', { method: 'GET' }),
    getBonusHistory: (skip: number = 0, limit: number = 20) => apiRequest<any[]>('/bonus/history', { 
      method: 'GET',
      params: { skip: skip.toString(), limit: limit.toString() }
    }),
    getNetworkEarnings: () => apiRequest<any>('/bonus/network-earnings', { method: 'GET' }),
  },
  
  // Auth endpoints
  auth: {
    login: (credentials: { phone: string; email?: string; password: string; remember_me?: boolean }) =>
      apiRequest<{ access_token: string; token_type: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
        requiresAuth: false,
      }),
    register: (userData: { 
      phone: string; // Phone is now required
      name: string; 
      password: string; 
      email?: string; // Email is now optional
      date_of_birth?: string; 
      gender?: string; 
      avatar?: string;
    }) =>
      apiRequest<{ id: string; member_id: string; phone: string; name: string; email?: string }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
        requiresAuth: false,
      }),
    resetPassword: (passwordData: { 
      current_password: string; 
      new_password: string; 
      confirm_password: string;
    }) =>
      apiRequest<any>('/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify(passwordData),
        requiresAuth: true,
      }),
    // OTP endpoints
    sendOTP: (data: { phone: string; purpose: string }) =>
      apiRequest<{ message: string }>('/auth/send-otp', {
        method: 'POST',
        body: JSON.stringify(data),
        requiresAuth: false,
      }),
    verifyOTP: (data: { phone: string; otp: string }) =>
      apiRequest<{ message: string }>('/auth/verify-otp', {
        method: 'POST',
        body: JSON.stringify(data),
        requiresAuth: false,
      }),
    forgotPassword: (data: { phone: string }) =>
      apiRequest<{ message: string }>('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify(data),
        requiresAuth: false,
      }),
    resetPasswordWithOTP: (data: { 
      phone: string; 
      otp: string; 
      new_password: string; 
      confirm_password: string 
    }) =>
      apiRequest<{ message: string }>('/auth/reset-password-with-otp', {
        method: 'POST',
        body: JSON.stringify(data),
        requiresAuth: false,
      }),
  },

  // User endpoints
  user: {
    getCurrentUser: () => apiRequest<any>('/users/me', { method: 'GET' }),
    me: () => apiRequest<any>('/users/me', { method: 'GET' }),
    profile: () => apiRequest<any>('/users/me/profile', { method: 'GET' }),
    update: (userData: any) => apiRequest<any>('/users/me', {
      method: 'PUT',
      body: JSON.stringify(userData),
    }),
    uploadAvatar: (formData: FormData) => apiUploadRequest('/users/me/avatar', formData),
    uploadKYCDocument: (formData: FormData) => apiUploadRequest('/users/me/kyc-document', formData),
  },
  
  // Referral endpoints
  referrals: {
    getMyCode: () => apiRequest<{referral_code: string, referral_link: string}>('/referrals/my-code', { method: 'GET' }),
    getMyReferrals: () => apiRequest<any[]>('/referrals/my-referrals', { method: 'GET' }),
    getNetworkData: () => apiRequest<{
      summary: {
        downline: string;
        activeCount: number;
        inactiveCount: number;
        blockedCount: number;
        totalCount: number;
      };
      teamMembers: Array<{
        id: string;
        name: string;
        userId: string;
        status: string;
        joinDate: string;
        avatar: string;
      }>;
      networkTree: any;
    }>('/referrals/network-data', { method: 'GET' }),
  },

  // Profile endpoints
  profile: {
    get: () => apiRequest<any>('/profile'),
    update: (profileData: any) =>
      apiRequest<any>('/profile', {
        method: 'PUT',
        body: JSON.stringify(profileData),
      }),
    getAddresses: () => apiRequest<any[]>('/addresses'),
    createAddress: (addressData: any) =>
      apiRequest<any>('/addresses', {
        method: 'POST',
        body: JSON.stringify(addressData),
      }),
    updateAddress: (addressId: string, addressData: any) =>
      apiRequest<any>(`/addresses/${addressId}`, {
        method: 'PUT',
        body: JSON.stringify(addressData),
      }),
    getBankDetails: () => apiRequest<any[]>('/bank-details'),
    createBankDetail: (bankData: any) =>
      apiRequest<any>('/bank-details', {
        method: 'POST',
        body: JSON.stringify(bankData),
      }),
    updateBankDetail: (bankId: string, bankData: any) =>
      apiRequest<any>(`/bank-details/${bankId}`, {
        method: 'PUT',
        body: JSON.stringify(bankData),
      }),
  },

  // Investment endpoints
  investments: {
    getAll: () => apiRequest<any[]>('/investments'),
    create: (investmentData: any) =>
      apiRequest<any>('/investments', {
        method: 'POST',
        body: JSON.stringify(investmentData),
      }),
    getById: (id: string) => apiRequest<any>(`/investments/${id}`),
    update: (id: string, investmentData: any) =>
      apiRequest<any>(`/investments/${id}`, {
        method: 'PUT',
        body: JSON.stringify(investmentData),
      }),
    getTeamInvestments: () => apiRequest<any[]>('/team-investments'),
    createTeamInvestment: (teamInvestmentData: any) =>
      apiRequest<any>('/team-investments', {
        method: 'POST',
        body: JSON.stringify(teamInvestmentData),
      }),
  },

  // Wallet endpoints
  wallets: {
    getIncomeWallet: () => apiRequest<any>('/income-wallet'),
    createIncomeTransaction: (transactionData: any) =>
      apiRequest<any>('/income-wallet/transactions', {
        method: 'POST',
        body: JSON.stringify(transactionData),
      }),
    getIncomeTransactions: () => apiRequest<any[]>('/income-wallet/transactions'),
    updateIncomeTransaction: (id: string, transactionData: any) =>
      apiRequest<any>(`/income-wallet/transactions/${id}`, {
        method: 'PUT',
        body: JSON.stringify(transactionData),
      }),
    requestWithdrawal: (amount: number) =>
      apiRequest<any>('/income-wallet/withdrawal', {
        method: 'POST',
        body: JSON.stringify({ amount }),
      }),
    getShoppingWallet: () => apiRequest<any>('/shopping-wallet'),
    createShoppingTransaction: (transactionData: any) =>
      apiRequest<any>('/shopping-wallet/transactions', {
        method: 'POST',
        body: JSON.stringify(transactionData),
      }),
    getShoppingTransactions: () => apiRequest<any[]>('/shopping-wallet/transactions'),
    getShoppingVouchers: () => apiRequest<any[]>('/shopping-wallet/vouchers'),
    createShoppingVoucher: (voucherData: any) =>
      apiRequest<any>('/shopping-wallet/vouchers', {
        method: 'POST',
        body: JSON.stringify(voucherData),
      }),
    updateShoppingVoucher: (id: string, voucherData: any) =>
      apiRequest<any>(`/shopping-wallet/vouchers/${id}`, {
        method: 'PUT',
        body: JSON.stringify(voucherData),
      }),
  },

  // Network endpoints
  network: {
    get: () => apiRequest<any>('/network'),
    update: (networkData: any) =>
      apiRequest<any>('/network', {
        method: 'PUT',
        body: JSON.stringify(networkData),
      }),
    join: (referralCode: string) =>
      apiRequest<any>(`/network/join/${referralCode}`, {
        method: 'POST',
      }),
    getBonuses: () => apiRequest<any[]>('/bonuses'),
    createBonus: (bonusData: any) =>
      apiRequest<any>('/bonuses', {
        method: 'POST',
        body: JSON.stringify(bonusData),
      }),
    updateBonus: (id: string, bonusData: any) =>
      apiRequest<any>(`/bonuses/${id}`, {
        method: 'PUT',
        body: JSON.stringify(bonusData),
      }),
    getNOCs: () => apiRequest<any[]>('/noc'),
    createNOC: (nocData: any) =>
      apiRequest<any>('/noc', {
        method: 'POST',
        body: JSON.stringify(nocData),
      }),
    updateNOC: (id: string, nocData: any) =>
      apiRequest<any>(`/noc/${id}`, {
        method: 'PUT',
        body: JSON.stringify(nocData),
      }),
  },
};

export default api;
