/**
 * Notification related types
 */

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning';
  read: boolean;
  created_at: string;
}

export interface NotificationCount {
  count: number;
}

export interface NotificationCreate {
  user_id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning';
}

export interface NotificationUpdate {
  read?: boolean;
}
