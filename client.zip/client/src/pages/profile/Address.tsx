import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Edit, Save, X, MapPin, AlertCircle } from "lucide-react";
import { useUserData } from "@/contexts/UserDataContext";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Address() {
  const { userData, addAddress, updateAddress } = useUserData();
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Create state to store form data
  const [formData, setFormData] = useState({
    address_type: "home",
    address_line1: "",
    address_line2: "",
    city: "",
    state: "",
    zip_code: "",
    country: "india",
    notes: "",
    is_default: true
  });
  
  // Initialize form data from existing address if available
  useEffect(() => {
    if (userData.addresses && userData.addresses.length > 0) {
      const defaultAddress = userData.addresses.find(addr => addr.is_default) || userData.addresses[0];
      setFormData({
        address_type: defaultAddress.address_type,
        address_line1: defaultAddress.address_line1,
        address_line2: defaultAddress.address_line2 || "",
        city: defaultAddress.city,
        state: defaultAddress.state,
        zip_code: defaultAddress.zip_code,
        country: defaultAddress.country,
        notes: defaultAddress.notes || "",
        is_default: defaultAddress.is_default
      });
    }
  }, [userData.addresses]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSelectChange = (id: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      // Check if we're updating an existing address or adding a new one
      if (userData.addresses && userData.addresses.length > 0) {
        const defaultAddress = userData.addresses.find(addr => addr.is_default) || userData.addresses[0];
        await updateAddress(defaultAddress.id!, formData);
      } else {
        await addAddress(formData);
      }
      
      setIsSaving(false);
      setIsEditing(false);
      toast.success("Address updated successfully");
    } catch (error) {
      console.error("Error saving address:", error);
      toast.error("Failed to save address. Please try again.");
      setIsSaving(false);
    }
  };
  
  const handleCancel = () => {
    // Reset form data to current address data
    if (userData.addresses && userData.addresses.length > 0) {
      const defaultAddress = userData.addresses.find(addr => addr.is_default) || userData.addresses[0];
      setFormData({
        address_type: defaultAddress.address_type,
        address_line1: defaultAddress.address_line1,
        address_line2: defaultAddress.address_line2 || "",
        city: defaultAddress.city,
        state: defaultAddress.state,
        zip_code: defaultAddress.zip_code,
        country: defaultAddress.country,
        notes: defaultAddress.notes || "",
        is_default: defaultAddress.is_default
      });
    }
    setIsEditing(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto"
    >
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Address Details</h1>
            <p className="text-muted-foreground mt-2">
              Manage your address information for shipping and billing purposes.
            </p>
            {userData.addresses && userData.addresses.length > 0 ? (
              <div className="flex items-center mt-3 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4 mr-1" />
                <span>Current Address: {userData.addresses[0].address_line1}, {userData.addresses[0].city}, {userData.addresses[0].state} {userData.addresses[0].zip_code}</span>
              </div>
            ) : (
              <Alert variant="destructive" className="mt-3">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  No address found. Please add your address details.
                </AlertDescription>
              </Alert>
            )}
          </div>
          {isEditing ? (
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={isSaving}>
                {isSaving ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Address
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1, duration: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Primary Address</CardTitle>
              <CardDescription>
                This address will be used as your default shipping address.
              </CardDescription>
            </CardHeader>
            {isEditing ? (
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="address_type">Address Type</Label>
                  <Select 
                    value={formData.address_type} 
                    onValueChange={(value) => handleSelectChange("address_type", value)}
                  >
                    <SelectTrigger id="address_type">
                      <SelectValue placeholder="Select address type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="home">Home</SelectItem>
                      <SelectItem value="work">Work</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address_line1">Address Line 1</Label>
                  <Input 
                    id="address_line1" 
                    placeholder="Street address, P.O. box" 
                    value={formData.address_line1}
                    onChange={handleChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address_line2">Address Line 2 (Optional)</Label>
                  <Input 
                    id="address_line2" 
                    placeholder="Apartment, suite, unit, building, floor, etc." 
                    value={formData.address_line2}
                    onChange={handleChange}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input 
                      id="city" 
                      placeholder="City" 
                      value={formData.city}
                      onChange={handleChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="state">State/Province</Label>
                    <Input 
                      id="state" 
                      placeholder="State/Province" 
                      value={formData.state}
                      onChange={handleChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="zip_code">Zip/Postal Code</Label>
                    <Input 
                      id="zip_code" 
                      placeholder="Zip/Postal Code" 
                      value={formData.zip_code}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country">Country</Label>
                  <Select 
                    value={formData.country}
                    onValueChange={(value) => handleSelectChange("country", value)}
                  >
                    <SelectTrigger id="country">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="india">India</SelectItem>
                      <SelectItem value="usa">United States</SelectItem>
                      <SelectItem value="uk">United Kingdom</SelectItem>
                      <SelectItem value="canada">Canada</SelectItem>
                      <SelectItem value="australia">Australia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>



                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes (Optional)</Label>
                  <Textarea 
                    id="notes" 
                    placeholder="Delivery instructions or other information"
                    className="min-h-[100px]"
                    value={formData.notes}
                    onChange={handleChange}
                  />
                </div>
                </CardContent>
              </form>
            ) : (
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Address Type</Label>
                      <div className="mt-1 text-lg font-semibold capitalize">{formData.address_type}</div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Address</Label>
                      <div className="mt-1 text-lg font-semibold">
                        {formData.address_line1}
                        {formData.address_line2 && <span>, {formData.address_line2}</span>}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">City, State, Zip</Label>
                      <div className="mt-1 text-lg font-semibold">
                        {formData.city}, {formData.state} {formData.zip_code}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Country</Label>
                      <div className="mt-1 text-lg font-semibold capitalize">{formData.country}</div>
                    </div>
                  </div>
                </div>
                
                {formData.notes && (
                  <div className="mt-4">
                    <Label className="text-sm font-medium text-muted-foreground">Additional Notes</Label>
                    <div className="mt-1 text-lg">{formData.notes}</div>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}
