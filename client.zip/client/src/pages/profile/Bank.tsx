import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Edit, Save, X, AlertCircle, CreditCard } from "lucide-react";
import { useUserData } from "@/contexts/UserDataContext";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Bank() {
  const { userData, addBankDetail, updateBankDetail } = useUserData();
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Create state to store form data
  const [formData, setFormData] = useState({
    account_holder_name: "",
    account_number: "",
    bank_name: "",
    branch_name: "",
    ifsc_code: "",
    is_default: true
  });
  
  // Initialize form data from existing bank details if available
  useEffect(() => {
    if (userData.bankDetails && userData.bankDetails.length > 0) {
      const defaultBank = userData.bankDetails.find(bank => bank.is_default) || userData.bankDetails[0];
      setFormData({
        account_holder_name: defaultBank.account_holder_name,
        account_number: defaultBank.account_number,
        bank_name: defaultBank.bank_name,
        branch_name: defaultBank.branch_name,
        ifsc_code: defaultBank.ifsc_code,
        is_default: defaultBank.is_default
      });
    }
  }, [userData.bankDetails]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      // Check if we're updating an existing bank detail or adding a new one
      if (userData.bankDetails && userData.bankDetails.length > 0) {
        const defaultBank = userData.bankDetails.find(bank => bank.is_default) || userData.bankDetails[0];
        await updateBankDetail(defaultBank.id!, formData);
      } else {
        await addBankDetail(formData);
      }
      
      setIsSaving(false);
      setIsEditing(false);
      toast.success("Bank details updated successfully");
    } catch (error) {
      console.error("Error saving bank details:", error);
      toast.error("Failed to save bank details. Please try again.");
      setIsSaving(false);
    }
  };
  
  const handleCancel = () => {
    // Reset form data to current bank data
    if (userData.bankDetails && userData.bankDetails.length > 0) {
      const defaultBank = userData.bankDetails.find(bank => bank.is_default) || userData.bankDetails[0];
      setFormData({
        account_holder_name: defaultBank.account_holder_name,
        account_number: defaultBank.account_number,
        bank_name: defaultBank.bank_name,
        branch_name: defaultBank.branch_name,
        ifsc_code: defaultBank.ifsc_code,
        is_default: defaultBank.is_default
      });
    }
    setIsEditing(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-4xl mx-auto"
    >
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Bank Account Details</h1>
            <p className="text-muted-foreground mt-2">
              Manage your bank account information for receiving payments.
            </p>
            {userData.bankDetails && userData.bankDetails.length > 0 ? (
              <div className="flex items-center mt-3 text-sm text-muted-foreground">
                <CreditCard className="w-4 h-4 mr-1" />
                <span>Current Bank: {userData.bankDetails[0].bank_name}, Account: {userData.bankDetails[0].account_number.replace(/\d(?=\d{4})/g, "*")}</span>
              </div>
            ) : (
              <Alert variant="destructive" className="mt-3">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  No bank account found. Please add your bank details.
                </AlertDescription>
              </Alert>
            )}
          </div>
          {isEditing ? (
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={isSaving}>
                {isSaving ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Bank Details
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1, duration: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Bank Account Information</CardTitle>
              <CardDescription>
                This bank account will be used for all your payment transactions.
              </CardDescription>
            </CardHeader>
            {isEditing ? (
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="account_holder_name">Account Holder Name</Label>
                    <Input 
                      id="account_holder_name" 
                      placeholder="Full name as per bank records" 
                      value={formData.account_holder_name}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="account_number">Account Number</Label>
                    <Input 
                      id="account_number" 
                      placeholder="Your bank account number" 
                      value={formData.account_number}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="bank_name">Bank Name</Label>
                      <Input 
                        id="bank_name" 
                        placeholder="Name of your bank" 
                        value={formData.bank_name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="branch_name">Branch Name</Label>
                      <Input 
                        id="branch_name" 
                        placeholder="Branch name" 
                        value={formData.branch_name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ifsc_code">IFSC Code</Label>
                    <Input 
                      id="ifsc_code" 
                      placeholder="IFSC code of your bank branch" 
                      value={formData.ifsc_code}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </CardContent>
              </form>
            ) : (
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Account Holder</Label>
                      <div className="mt-1 text-lg font-semibold">{formData.account_holder_name}</div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Account Number</Label>
                      <div className="mt-1 text-lg font-semibold">
                        {formData.account_number.replace(/\d(?=\d{4})/g, "*")}
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Bank Name</Label>
                      <div className="mt-1 text-lg font-semibold">{formData.bank_name}</div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">Branch</Label>
                      <div className="mt-1 text-lg font-semibold">{formData.branch_name}</div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-muted-foreground">IFSC Code</Label>
                      <div className="mt-1 text-lg font-semibold">{formData.ifsc_code}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}
