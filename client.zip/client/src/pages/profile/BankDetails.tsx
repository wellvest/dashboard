import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Edit, Save, X } from "lucide-react";
import { toast } from "sonner";

// Dummy API data
const bankData = {
  accountHolderName: "MOHD INAM",
  bankName: "HDFC Bank Ltd",
  bankIFSC: "HDFC0002210",
  accountNumber: "50100024067411",
  branch: "Churmalpur"
};

export default function BankDetails() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(bankData);
  const [isSaving, setIsSaving] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSave = () => {
    setIsSaving(true);
    // Simulate API call
    setTimeout(() => {
      // Update the bank data
      Object.assign(bankData, formData);
      setIsSaving(false);
      setIsEditing(false);
      toast.success("Bank details updated successfully");
    }, 1000);
  };

  const handleCancel = () => {
    setFormData(bankData);
    setIsEditing(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Bank Details</h1>
        {isEditing ? (
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        ) : (
          <Button onClick={() => setIsEditing(true)}>
            <Edit className="w-4 h-4 mr-2" />
            Edit Details
          </Button>
        )}
      </div>

      <Card className="shadow-card border-0">
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="accountHolderName">Account Holder Name</Label>
                {isEditing ? (
                  <Input
                    id="accountHolderName"
                    value={formData.accountHolderName}
                    onChange={handleChange}
                    className="mt-2"
                  />
                ) : (
                  <div className="mt-1 text-lg font-semibold">
                    {formData.accountHolderName}
                  </div>
                )}
              </div>
              
              <div>
                <Label htmlFor="bankName">Bank Name</Label>
                {isEditing ? (
                  <Input
                    id="bankName"
                    value={formData.bankName}
                    onChange={handleChange}
                    className="mt-2"
                  />
                ) : (
                  <div className="mt-1 text-lg font-semibold">
                    {formData.bankName}
                  </div>
                )}
              </div>
              
              <div>
                <Label htmlFor="bankIFSC">Bank IFSC</Label>
                {isEditing ? (
                  <Input
                    id="bankIFSC"
                    value={formData.bankIFSC}
                    onChange={handleChange}
                    className="mt-2"
                  />
                ) : (
                  <div className="mt-1 text-lg font-semibold">
                    {formData.bankIFSC}
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="accountNumber">A/C No.</Label>
                {isEditing ? (
                  <Input
                    id="accountNumber"
                    value={formData.accountNumber}
                    onChange={handleChange}
                    className="mt-2"
                  />
                ) : (
                  <div className="mt-1 text-lg font-semibold">
                    {formData.accountNumber}
                  </div>
                )}
              </div>
              
              <div>
                <Label htmlFor="branch">Branch</Label>
                {isEditing ? (
                  <Input
                    id="branch"
                    value={formData.branch}
                    onChange={handleChange}
                    className="mt-2"
                  />
                ) : (
                  <div className="mt-1 text-lg font-semibold">
                    {formData.branch}
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}