import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Edit, Save, X, Upload, AlertCircle, CheckCircle2, Clock } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import axios from "axios";

export default function KYC() {
  const { profile, fetchUserProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [formData, setFormData] = useState<{
    documentType: string;
    documentNumber: string;
  }>({ 
    documentType: profile?.kyc_document_type || "Aadhar Card",
    documentNumber: profile?.kyc_document_number || ""
  });

  // Update form data when profile changes
  useEffect(() => {
    if (profile) {
      setFormData({
        documentType: profile.kyc_document_type || "Aadhar Card",
        documentNumber: profile.kyc_document_number || ""
      });
    }
  }, [profile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleSave = async () => {
    if (!selectedFile && !formData.documentNumber) {
      toast.error("Please provide document number and upload an image");
      return;
    }

    setIsSaving(true);
    try {
      // Create form data for file upload
      const formDataToSend = new FormData();
      formDataToSend.append("document_type", formData.documentType);
      formDataToSend.append("document_number", formData.documentNumber);
      
      if (selectedFile) {
        formDataToSend.append("document_file", selectedFile);
      }
      
      // Get authentication token
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('Authentication required. Please login.');
      }
      
      // Send to API
      await axios.post("/api/users/me/kyc", formDataToSend, {
        headers: {
          "Content-Type": "multipart/form-data",
          "Authorization": `Bearer ${token}`
        }
      });
      
      // Refresh user profile data
      await fetchUserProfile();
      
      setIsEditing(false);
      setSelectedFile(null);
      toast.success("KYC information submitted successfully. Waiting for verification.");
    } catch (error: any) {
      console.error("Error updating KYC:", error);
      toast.error(error.response?.data?.detail || "Failed to update KYC information");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (profile) {
      setFormData({
        documentType: profile.kyc_document_type || "Aadhar Card",
        documentNumber: profile.kyc_document_number || ""
      });
    }
    setIsEditing(false);
    setSelectedFile(null);
  };

  // Get verification status badge
  const getVerificationStatus = () => {
    if (!profile) return null;
    
    if (profile.kyc_document_url && profile.kyc_verified) {
      return (
        <Badge className="bg-green-500 hover:bg-green-600">
          <CheckCircle2 className="w-4 h-4 mr-1" /> Verified
        </Badge>
      );
    } else if (profile.kyc_document_url && !profile.kyc_verified) {
      return (
        <Badge className="bg-amber-500 hover:bg-amber-600">
          <Clock className="w-4 h-4 mr-1" /> Pending Verification
        </Badge>
      );
    } else {
      return (
        <Badge variant="outline" className="text-red-500 border-red-500">
          <AlertCircle className="w-4 h-4 mr-1" /> Not Submitted
        </Badge>
      );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-bold">KYC Verification</h1>
          {getVerificationStatus()}
        </div>
        
        {!isEditing && !isSaving && (
          <Button 
            onClick={() => setIsEditing(true)}
            disabled={profile?.kyc_verified}
            variant={profile?.kyc_verified ? "outline" : "default"}
          >
            <Edit className="w-4 h-4 mr-2" />
            {profile?.kyc_document_url ? "Update KYC" : "Submit KYC"}
          </Button>
        )}
        
        {isEditing && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        )}
      </div>

      {profile?.kyc_verified && (
        <Alert className="bg-green-50 border-green-200">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertTitle>Verification Complete</AlertTitle>
          <AlertDescription>
            Your KYC documents have been verified successfully. You now have full access to all features.
          </AlertDescription>
        </Alert>
      )}

      {profile?.kyc_document_url && !profile.kyc_verified && (
        <Alert className="bg-amber-50 border-amber-200">
          <Clock className="h-4 w-4 text-amber-600" />
          <AlertTitle>Verification Pending</AlertTitle>
          <AlertDescription>
            Your KYC documents have been submitted and are pending verification by our team. This usually takes 24-48 hours.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Document Image */}
        <Card className="shadow-md border border-gray-200">
          <CardHeader>
            <CardTitle>Identity Document</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {(selectedFile || profile?.kyc_document_url) ? (
              <div className="overflow-hidden rounded-lg border border-gray-200">
                <img 
                  src={selectedFile ? URL.createObjectURL(selectedFile) : profile?.kyc_document_url || ''}
                  alt="Identity Document"
                  className="w-full h-auto object-contain max-h-[300px]"
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-[300px] bg-gray-50 rounded-lg border border-dashed border-gray-300">
                <div className="text-center">
                  <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">No document uploaded</p>
                </div>
              </div>
            )}
            
            {isEditing && (
              <div className="mt-4">
                <Label htmlFor="documentFile" className="cursor-pointer">
                  <div className="flex items-center justify-center p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-primary">
                    <div className="text-center">
                      <Upload className="mx-auto h-8 w-8 text-gray-400" />
                      <div className="mt-2 flex text-sm text-gray-600">
                        <span className="relative rounded-md font-medium text-primary hover:text-primary-dark">
                          {selectedFile ? "Change document" : "Upload document"}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        PNG, JPG, PDF up to 5MB
                      </p>
                    </div>
                  </div>
                  <input
                    id="documentFile"
                    name="documentFile"
                    type="file"
                    className="sr-only"
                    accept="image/*,.pdf"
                    onChange={handleFileChange}
                  />
                </Label>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Document Details */}
        <Card className="shadow-md border border-gray-200">
          <CardHeader>
            <CardTitle>Document Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="documentType">Document Type</Label>
                <Input 
                  id="documentType"
                  value={formData.documentType}
                  onChange={handleChange}
                  readOnly={!isEditing || profile?.kyc_verified}
                  className={`mt-2 ${(!isEditing || profile?.kyc_verified) ? 'bg-gray-50' : ''}`}
                />
              </div>
              <div>
                <Label htmlFor="documentNumber">Document Number</Label>
                <Input 
                  id="documentNumber"
                  value={formData.documentNumber}
                  onChange={handleChange}
                  readOnly={!isEditing || profile?.kyc_verified}
                  className={`mt-2 ${(!isEditing || profile?.kyc_verified) ? 'bg-gray-50' : ''}`}
                />
              </div>
              
              {profile?.kyc_document_url && (
                <div className="pt-4 border-t border-gray-200 mt-6">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Submission Date:</span>
                    <span className="text-sm text-gray-600">{new Date().toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm font-medium">Status:</span>
                    <span className="text-sm">
                      {profile.kyc_verified ? (
                        <span className="text-green-600 font-medium">Verified</span>
                      ) : (
                        <span className="text-amber-600 font-medium">Pending Verification</span>
                      )}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}