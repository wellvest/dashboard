import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { api } from "@/utils/api";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import { Loader2, ChevronLeft, ChevronRight } from "lucide-react";

// Define types for API responses
type BonusSummary = {
  total_bonus: number;
  tds_percentage: number;
  tds_amount: number;
  net_amount: number;
  wallet_balance: number;
  recent_bonuses: BonusRecord[];
};

type BonusRecord = {
  id: string;
  amount: number;
  bonus_type: string;
  description: string;
  created_at: string;
  referrer_name: string;
  referrer_id: string;
  referrer_avatar?: string;
  is_paid: boolean;
};

type NetworkEarnings = {
  total_earnings: number;
  level_earnings: {
    level1: number;
    level2: number;
    level3: number;
  };
  direct_referrals_count: number;
};

// Default empty state
const emptyBonusSummary: BonusSummary = {
  total_bonus: 0,
  tds_percentage: 6.5,
  tds_amount: 0,
  net_amount: 0,
  wallet_balance: 0,
  recent_bonuses: []
};

const emptyNetworkEarnings: NetworkEarnings = {
  total_earnings: 0,
  level_earnings: {
    level1: 0,
    level2: 0,
    level3: 0
  },
  direct_referrals_count: 0
};

export default function Bonus() {
  const { toast } = useToast();
  const [bonusSummary, setBonusSummary] = useState<BonusSummary>(emptyBonusSummary);
  const [networkEarnings, setNetworkEarnings] = useState<NetworkEarnings>(emptyNetworkEarnings);
  const [bonusHistory, setBonusHistory] = useState<BonusRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("summary");
  const [currentMonth, setCurrentMonth] = useState(format(new Date(), "MMMM yyyy"));
  const [currentPage, setCurrentPage] = useState(1);
  const [userProfile, setUserProfile] = useState({
    name: "",
    id: "",
    avatar: ""
  });

  const itemsPerPage = 5;
  
  // Fetch user profile
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const response = await api.user.getCurrentUser();
        setUserProfile({
          name: response.name,
          id: response.member_id || "",
          avatar: response.avatar || ""
        });
      } catch (error) {
        console.error("Error fetching user profile:", error);
      }
    };
    
    fetchUserProfile();
  }, []);
  
  // Fetch bonus data
  useEffect(() => {
    const fetchBonusData = async () => {
      setIsLoading(true);
      try {
        // Fetch bonus summary
        const summaryResponse = await api.bonus.getBonusSummary();
        setBonusSummary(summaryResponse);
        
        // Fetch network earnings
        const earningsResponse = await api.bonus.getNetworkEarnings();
        setNetworkEarnings(earningsResponse);
        
        // Fetch bonus history
        const historyResponse = await api.bonus.getBonusHistory();
        setBonusHistory(historyResponse);
      } catch (error) {
        console.error("Error fetching bonus data:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load bonus data. Please try again later."
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchBonusData();
  }, [toast]);
  
  // Pagination for bonus history
  const totalPages = Math.ceil(bonusHistory.length / itemsPerPage);
  const paginatedHistory = bonusHistory.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  // Handle page change
  const changePage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 2
    }).format(amount);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">My Bonus & Earnings</h1>
        <Select value={currentMonth} onValueChange={setCurrentMonth}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Select Month" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={format(new Date(), "MMMM yyyy")}>{format(new Date(), "MMMM yyyy")}</SelectItem>
            <SelectItem value={format(new Date(new Date().setMonth(new Date().getMonth() - 1)), "MMMM yyyy")}>
              {format(new Date(new Date().setMonth(new Date().getMonth() - 1)), "MMMM yyyy")}
            </SelectItem>
            <SelectItem value={format(new Date(new Date().setMonth(new Date().getMonth() - 2)), "MMMM yyyy")}>
              {format(new Date(new Date().setMonth(new Date().getMonth() - 2)), "MMMM yyyy")}
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* User Profile Card */}
      <Card className="shadow-card border-0 bg-gradient-card">
        <CardContent className="p-8 text-center">
          <Avatar className="h-20 w-20 mx-auto mb-4">
            <AvatarImage src={userProfile.avatar} alt={userProfile.name} />
            <AvatarFallback className="text-xl font-semibold">
              {userProfile.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <h2 className="text-xl font-bold mb-1">{userProfile.name}</h2>
          <p className="text-muted-foreground">{userProfile.id}</p>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="summary">Bonus Summary</TabsTrigger>
            <TabsTrigger value="network">Network Earnings</TabsTrigger>
            <TabsTrigger value="history">Bonus History</TabsTrigger>
          </TabsList>
          
          {/* Bonus Summary Tab */}
          <TabsContent value="summary" className="mt-4">
            <Card className="shadow-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{currentMonth}</span>
                  <span className="text-sm font-normal text-primary cursor-pointer hover:underline">
                    History
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b">
                  <span className="font-medium">Total Bonus Earned</span>
                  <span className="font-semibold text-lg">{formatCurrency(bonusSummary.total_bonus)}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b">
                  <span className="font-medium">TDS ({bonusSummary.tds_percentage}%)</span>
                  <span className="font-semibold text-lg text-red-600">{formatCurrency(bonusSummary.tds_amount)}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b">
                  <span className="font-medium">Net Amount</span>
                  <span className="font-semibold text-lg">{formatCurrency(bonusSummary.net_amount)}</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="font-bold text-lg">WALLET BALANCE</span>
                  <span className="font-bold text-xl text-success">{formatCurrency(bonusSummary.wallet_balance)}</span>
                </div>
              </CardContent>
            </Card>
            
            {/* Recent Bonuses */}
            {bonusSummary.recent_bonuses.length > 0 && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Recent Bonuses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {bonusSummary.recent_bonuses.map((bonus) => (
                      <div key={bonus.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="bg-primary/10 p-2 rounded-full">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={bonus.referrer_avatar} alt={bonus.referrer_name} />
                              <AvatarFallback>
                                {bonus.referrer_name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                          </div>
                          <div>
                            <p className="font-medium">{bonus.description}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(bonus.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-success">{formatCurrency(bonus.amount)}</p>
                          <Badge variant={bonus.is_paid ? "secondary" : "outline"}>
                            {bonus.is_paid ? "Paid" : "Pending"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          {/* Network Earnings Tab */}
          <TabsContent value="network" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Direct Referrals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-2xl font-bold">{networkEarnings.direct_referrals_count}</p>
                      <p className="text-xs text-muted-foreground">Total direct referrals</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Level 1 Earnings (4%)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-2xl font-bold text-success">{formatCurrency(networkEarnings.level_earnings.level1)}</p>
                      <p className="text-xs text-muted-foreground">From direct referrals</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Network Earnings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-2xl font-bold text-primary">{formatCurrency(networkEarnings.total_earnings)}</p>
                      <p className="text-xs text-muted-foreground">From all levels</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Earnings By Level</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h3 className="font-medium">Level 1 (4%)</h3>
                      <p className="text-xl font-bold text-success mt-2">{formatCurrency(networkEarnings.level_earnings.level1)}</p>
                      <p className="text-xs text-muted-foreground mt-1">Direct referrals</p>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h3 className="font-medium">Level 2 (1.5%)</h3>
                      <p className="text-xl font-bold text-success mt-2">{formatCurrency(networkEarnings.level_earnings.level2)}</p>
                      <p className="text-xs text-muted-foreground mt-1">Referrals of referrals</p>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h3 className="font-medium">Level 3 (0.5%)</h3>
                      <p className="text-xl font-bold text-success mt-2">{formatCurrency(networkEarnings.level_earnings.level3)}</p>
                      <p className="text-xs text-muted-foreground mt-1">Third level</p>
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg bg-muted/20">
                    <div className="flex justify-between items-center">
                      <h3 className="font-bold">Total Network Earnings</h3>
                      <p className="text-xl font-bold text-primary">{formatCurrency(networkEarnings.total_earnings)}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Bonus History Tab */}
          <TabsContent value="history" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Bonus History</CardTitle>
              </CardHeader>
              <CardContent>
                {bonusHistory.length > 0 ? (
                  <div className="space-y-4">
                    {paginatedHistory.map((bonus) => (
                      <div key={bonus.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={bonus.referrer_avatar} alt={bonus.referrer_name} />
                            <AvatarFallback>
                              {bonus.referrer_name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{bonus.description}</p>
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline">{bonus.bonus_type}</Badge>
                              <p className="text-sm text-muted-foreground">
                                {new Date(bonus.created_at).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-success">{formatCurrency(bonus.amount)}</p>
                          <Badge variant={bonus.is_paid ? "secondary" : "outline"}>
                            {bonus.is_paid ? "Paid" : "Pending"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    
                    {/* Pagination */}
                    {totalPages > 1 && (
                      <div className="flex items-center justify-between mt-4">
                        <p className="text-sm text-muted-foreground">
                          Showing {Math.min((currentPage - 1) * itemsPerPage + 1, bonusHistory.length)} - {Math.min(currentPage * itemsPerPage, bonusHistory.length)} of {bonusHistory.length}
                        </p>
                        <div className="flex items-center space-x-2">
                          <Button 
                            variant="outline" 
                            size="icon" 
                            onClick={() => changePage(currentPage - 1)}
                            disabled={currentPage === 1}
                          >
                            <ChevronLeft className="h-4 w-4" />
                          </Button>
                          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                            <Button
                              key={page}
                              variant={page === currentPage ? "default" : "outline"}
                              size="sm"
                              onClick={() => changePage(page)}
                              className="w-8 h-8 p-0"
                            >
                              {page}
                            </Button>
                          ))}
                          <Button 
                            variant="outline" 
                            size="icon" 
                            onClick={() => changePage(currentPage + 1)}
                            disabled={currentPage === totalPages}
                          >
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No bonus history found</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}