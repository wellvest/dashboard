import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { FileText, AlertTriangle, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useWallet } from "@/contexts/WalletContext";
import { useUserData } from "@/contexts/UserDataContext";
import NOCDocument from "./NOCDocument";
import axios from "axios";

// API URL configuration
const API_URL = import.meta.env.VITE_API_URL || '';

export default function NOC() {
  const navigate = useNavigate();
  const [isEligible, setIsEligible] = useState<boolean | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const { toast } = useToast();
  const { user } = useAuth();
  const { walletData, totalIncomeBalance, totalShoppingBalance } = useWallet();
  const { userData } = useUserData();

  useEffect(() => {
    const checkEligibility = async () => {
      try {
        // Check if user has a plan or balance > 0
        const planAmount = userData.profile?.plan_amount || 0;
        const hasBalance = totalIncomeBalance > 0 || totalShoppingBalance > 0;
        
        if (planAmount > 0 || hasBalance) {
          setIsEligible(true);
        } else {
          setIsEligible(false);
        }
        
        setLoading(false);
      } catch (error) {
        console.error("Error checking NOC eligibility:", error);
        setIsEligible(false);
        setLoading(false);
      }
    };

    checkEligibility();
  }, [userData, totalIncomeBalance, totalShoppingBalance]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Checking eligibility...</p>
      </div>
    );
  }

  if (!isEligible) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">NOC Document</h1>
          <span className="px-2 py-1 text-xs bg-red-100 text-red-600 rounded-full font-medium">
            New!
          </span>
        </div>

        <Card className="shadow-card border-0">
          <CardContent className="p-12 text-center">
            <div className="flex flex-col items-center space-y-4">
              <div className="p-6 rounded-full bg-amber-100">
                <AlertTriangle className="h-12 w-12 text-amber-600" />
              </div>
              <h3 className="text-xl font-semibold">
                Not Eligible for NOC Document
              </h3>
              <p className="text-muted-foreground max-w-md">
                You must have an active investment plan or a positive wallet balance to access the NOC document.
              </p>
              <Button 
                onClick={() => navigate('/plan')} 
                className="mt-4"
              >
                Explore Investment Plans
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <NOCDocument />;
}