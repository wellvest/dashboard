import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2, Download, FileText } from "lucide-react";
import axios from "axios";

// API URL configuration
const API_URL = import.meta.env.VITE_API_URL || '';

interface NOCData {
  user_id: string;
  member_id: string;
  name: string;
  plan_amount: number;
  amount_paid: number;
  total_amount_paid: number;
  incentive_amount: number;
  foreclosure_charges: number;
  final_payable_amount: number;
  due_date: string;
  company_name: string;
  generated_at: string;
}

export default function NOCDocument() {
  const [nocData, setNocData] = useState<NOCData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [downloading, setDownloading] = useState<boolean>(false);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    const fetchNOCData = async () => {
      try {
        console.log('Fetching NOC data from API...');
        const token = localStorage.getItem('token');
        console.log('Token available:', !!token);
        
        const response = await axios.get(`${API_URL}/api/noc/document`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        
        console.log('NOC API response status:', response.status);
        console.log('NOC data from API:', response.data);
        
        if (!response.data) {
          console.error('Empty response data from NOC API');
          toast({
            title: "Warning",
            description: "Received empty data from server. Some information may be missing.",
            variant: "destructive",
          });
          setNocData({
            user_id: '',
            member_id: 'N/A',
            name: 'User',
            plan_amount: 0,
            amount_paid: 0,
            total_amount_paid: 0,
            incentive_amount: 0,
            foreclosure_charges: 0,
            final_payable_amount: 0,
            due_date: new Date().toISOString(),
            company_name: 'WellVest Financial Services Pvt. Ltd.',
            generated_at: new Date().toISOString()
          });
        } else {
          setNocData(response.data);
        }
        setLoading(false);
      } catch (error: any) {
        console.error("Error fetching NOC data:", error);
        console.error("Error details:", error.response?.data);
        toast({
          title: "Error",
          description: error.response?.data?.detail || "Failed to load NOC document. Please try again.",
          variant: "destructive",
        });
        setLoading(false);
      }
    };

    fetchNOCData();
  }, [toast]);

  const handleDownloadPDF = async () => {
    setDownloading(true);
    try {
      // Open the HTML in a new window
      const response = await axios.get(`${API_URL}/api/noc/download`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        },
        responseType: 'text'
      });
      
      // Create a new window with the HTML content
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(response.data);
        printWindow.document.close();
        
        // Give time for the content to load
        setTimeout(() => {
          // Trigger print dialog
          printWindow.print();
          
          // Close the window after printing (optional)
          // printWindow.close();
          
          setDownloading(false);
          
          toast({
            title: "Success",
            description: "NOC document opened for printing/saving as PDF.",
          });
        }, 1000);
      } else {
        toast({
          title: "Warning",
          description: "Please allow pop-ups to view and download the NOC document.",
        });
        setDownloading(false);
      }
    } catch (error) {
      console.error("Error downloading NOC document:", error);
      toast({
        title: "Error",
        description: "Failed to download NOC document. Please try again.",
        variant: "destructive",
      });
      setDownloading(false);
    }
  };

  const formatCurrency = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined || isNaN(amount)) {
      return '₹0.00/-';
    }
    // Format to match the download view format with trailing /- 
    return `₹${parseFloat(amount.toString()).toFixed(2)}/-`;
  };

  const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) {
      return new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      });
    }
    
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        throw new Error('Invalid date');
      }
      
      // Format to match the download view format (DD-MM-YYYY)
      return `${date.getDate().toString().padStart(2, '0')}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getFullYear()}`;
    } catch (error) {
      console.error('Error formatting date:', error);
      const now = new Date();
      return `${now.getDate().toString().padStart(2, '0')}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getFullYear()}`;
    }
  };
  
  // Format due date in YYYY-MM-DD format to match download view
  const formatDueDate = (dateString: string | null | undefined) => {
    if (!dateString) {
      return new Date().toISOString().split('T')[0];
    }
    
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        throw new Error('Invalid date');
      }
      
      return date.toISOString().split('T')[0];
    } catch (error) {
      console.error('Error formatting due date:', error);
      return new Date().toISOString().split('T')[0];
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Loading NOC document...</p>
      </div>
    );
  }

  if (!nocData) {
    return (
      <div className="flex flex-col justify-center items-center h-64">
        <FileText className="h-16 w-16 text-muted-foreground mb-4" />
        <p className="text-lg font-medium">No NOC document available</p>
        <p className="text-muted-foreground">You must have an active plan or positive balance to access the NOC document.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">No Dues Certificate (NOC)</h1>
        <Button 
          onClick={handleDownloadPDF} 
          disabled={downloading}
          className="flex items-center"
        >
          {downloading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Downloading...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Download PDF
            </>
          )}
        </Button>
      </div>

      <Card className="shadow-card border-2 border-border">
        <CardContent className="p-0">
          <div className="bg-primary text-primary-foreground p-6 text-center">
            <h2 className="text-xl font-bold">ACKNOWLEDGMENT CERTIFICATE CUM NO DUES (NOC) CERTIFICATE</h2>
          </div>
          
          <div className="p-6 space-y-6">
            <div className="flex justify-end">
              <p><strong>Date:</strong> {formatDate(nocData.generated_at)}</p>
            </div>
            
            <div>
              <p><strong>Subject:</strong> Final Settlement and Closure (NOC) of Financing Agreement (Financer ID: {nocData.member_id || 'N/A'})</p>
            </div>
            
            <div>
              <p>Dear {nocData.name || 'User'},</p>
              <p className="mt-4">
                We, <strong>{nocData.company_name || 'WellVest Financial Services Pvt. Ltd.'}</strong>, hereby acknowledge and confirm the following in respect of
                the financing arrangement entered into with you under Financer ID: <strong>{nocData.member_id || 'N/A'}</strong>:
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">1. Financial Summary:</h3>
              <div className="border rounded-md overflow-hidden">
                <table className="w-full">
                  <tbody>
                    <tr className="border-b">
                      <td className="p-3">Total Principal Amount Financed: INR</td>
                      <td className="p-3 font-semibold text-right">{formatCurrency(nocData.plan_amount)}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Amount Paid to Patron Till Date: INR</td>
                      <td className="p-3 font-semibold text-right">{formatCurrency(nocData.amount_paid)}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Total Amount Paid to Patron: INR</td>
                      <td className="p-3 font-semibold text-right">{formatCurrency(nocData.total_amount_paid)}</td>
                    </tr>
                    <tr className="border-b bg-muted/30">
                      <td className="p-3" colSpan={2}>
                        Principal Adjustment: From the initial principal amount, the amount already paid to the patron
                        as of the termination date shall be deducted.
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Total Incentive Amount Paid (if any): INR</td>
                      <td className="p-3 font-semibold text-right">{formatCurrency(nocData.incentive_amount)}</td>
                    </tr>
                    <tr className="border-b bg-amber-50">
                      <td className="p-3" colSpan={2}>
                        <strong>This Incentive amount is not being deducted by the company</strong>
                      </td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Foreclosure Charges</td>
                      <td className="p-3 font-semibold text-right">{formatCurrency(nocData.foreclosure_charges)}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">Final Payable Amount (if any): INR</td>
                      <td className="p-3 font-semibold text-right">{formatCurrency(nocData.final_payable_amount)}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-3">The due date for final payment is:</td>
                      <td className="p-3 font-semibold text-right">{formatDueDate(nocData.due_date)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="mt-2">
                In case the amount already paid to the patron exceeds the principal amount originally financed, such excess shall remain with the patron/financier, and <strong>{nocData.company_name || 'WellVest Financial Services Pvt. Ltd.'}</strong> shall make no claim over the same.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">3. Termination of Agreement:</h3>
              <p>
                Upon execution of this certificate and form, once the payment is credited to your bank account,
                all the original financing agreements under this financer ID shall be considered closed, and all
                obligations between the parties shall cease to exist with no further liability or dues remaining.
              </p>
              
              <p className="mt-4">
                We request you to kindly authenticate this NOC form by entering one time password to be
                received on your phone as your confirmation and acceptance of the above.
              </p>
              
              <p className="mt-4">Thank you for your cooperation and association.</p>
            </div>
            
            <div className="mt-8 pt-4 border-t text-sm text-muted-foreground">
              <p>Generated on: {formatDate(nocData.generated_at)}</p>
              <p>This is a system-generated document and does not require a physical signature.</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="flex justify-center mt-6">
        <Button 
          onClick={handleDownloadPDF} 
          disabled={downloading}
          size="lg"
          className="flex items-center"
        >
          {downloading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Downloading...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Download PDF
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
