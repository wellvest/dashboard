import { useNavigate } from "react-router-dom";
import { DashboardCard } from "@/components/dashboard/DashboardCard";
import { ProfileCompletionStatus } from "@/components/dashboard/ProfileCompletionStatus";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Target, 
  FileText, 
  Users, 
  Gift, 
  Network, 
  Wallet, 
  ShoppingBag,
  RefreshCw,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";
import { useInvestment } from "@/contexts/InvestmentContext";
import { useWallet } from "@/contexts/WalletContext";
import { useNetwork } from "@/contexts/NetworkContext";
import { useState, useEffect } from "react";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { userData, fetchUserData } = useUserData();
  const { investmentData, fetchInvestments, totalInvestment } = useInvestment();
  const { walletData, fetchWalletData, totalIncomeBalance, totalShoppingBalance } = useWallet();
  const { networkData, fetchNetworkData, totalNetworkSize, totalBonusAmount } = useNetwork();
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Load data when component mounts
  useEffect(() => {
    refreshAllData();
  }, []);

  // Function to refresh all data
  const refreshAllData = async () => {
    setIsRefreshing(true);
    try {
      await Promise.all([
        fetchUserData(),
        fetchInvestments(),
        fetchWalletData(),
        fetchNetworkData()
      ]);
    } catch (error) {
      console.error('Error refreshing data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  const dashboardCards = [
    { title: "My Plan", icon: Target, path: "/plan" },
    { title: "NOC", icon: FileText, path: "/noc", variant: "new" as const },
    { title: "My Team Plan", icon: Users, path: "/plan/team", variant: "coming-soon" as const },
    { title: "My B", icon: Gift, path: "/bonus" },
    { title: "My Network", icon: Network, path: "/network", variant: "new" as const },
    { title: "Income Wallet", icon: Wallet, path: "/income-wallet" },
    { title: "Shopping Voucher", icon: ShoppingBag, path: "/shopping-voucher" }
  ];

  return (
    <div className="space-y-8 p-6">
      {/* User Profile Header */}
      <Card className="bg-gradient-primary border-0 shadow-card overflow-hidden">
        <CardContent className="p-8 relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-xl"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
          <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <Avatar className="h-20 w-20 border-4 border-white/20 shadow-lg">
                <AvatarImage src={user?.avatar || "/api/placeholder/64/64"} alt={user?.name || "User"} />
                <AvatarFallback className="text-xl font-semibold bg-white/20 text-white">
                  {user?.name ? user.name.split(' ').map(n => n[0]).join('') : 'U'}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-3xl font-bold text-white mb-1">{user?.name || "User"}</h1>
                <p className="text-white/70 text-sm mb-2">CUS. ID: {user?.member_id || ""}</p>
                <div className="bg-white/20 px-4 py-1.5 rounded-full inline-block">
                  <p className="text-white font-semibold">My Plan: ₹{userData.profile?.plan_amount?.toFixed(2) || "0.00"}</p>
                </div>
              </div>
            </div>
            <Button 
              variant="outline" 
              className="bg-white/10 text-white border-white/20 hover:bg-white/20 hover:text-white"
              onClick={refreshAllData}
              disabled={isRefreshing}
            >
              {isRefreshing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Refreshing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </>
              )}
            </Button>
          </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Completion Status */}
      <div className="mb-8">
        <ProfileCompletionStatus />
      </div>

      {/* Dashboard Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-2">
        {dashboardCards.map((card) => (
          <DashboardCard
            key={card.title}
            title={card.title}
            icon={card.icon}
            variant={card.variant}
            onClick={() => navigate(card.path)}
          />
        ))}
      </div>
    </div>
  );
}