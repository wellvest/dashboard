import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";
import api from "@/utils/api";
import { formatCurrency } from "@/utils/format";
import { Loader2, Check } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Types
interface IncomeWalletData {
  id: string;
  user_id: string;
  balance: number;
  transactions: IncomeTransactionData[];
}

interface IncomeTransactionData {
  id: string;
  wallet_id: string;
  amount: number;
  transaction_type: "credit" | "debit";
  description: string;
  status: "completed" | "pending" | "failed";
  created_at: string;
  updated_at: string;
}

interface WithdrawalFormData {
  amount: number;
}

export default function IncomeWallet() {
  const [loading, setLoading] = useState(true);
  const [walletData, setWalletData] = useState<IncomeWalletData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [withdrawalDialogOpen, setWithdrawalDialogOpen] = useState(false);
  const [withdrawalSuccess, setWithdrawalSuccess] = useState(false);
  const [withdrawalAmount, setWithdrawalAmount] = useState(0);
  const [withdrawalLoading, setWithdrawalLoading] = useState(false);
  const [withdrawalError, setWithdrawalError] = useState<string | null>(null);

  // Calculate totals
  const totalCredit = walletData?.transactions
    .filter(t => t.transaction_type === "credit")
    .reduce((sum, t) => sum + t.amount, 0) || 0;

  const totalDebit = walletData?.transactions
    .filter(t => t.transaction_type === "debit")
    .reduce((sum, t) => sum + t.amount, 0) || 0;

  const balance = walletData?.balance || 0;

  const fetchWalletData = async () => {
    try {
      setLoading(true);
      const data = await api.wallets.getIncomeWallet();
      setWalletData(data);
      setError(null);
    } catch (err: any) {
      console.error("Failed to fetch wallet data:", err);
      setError(err.message || "Failed to fetch wallet data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWalletData();
  }, []);

  const { register, handleSubmit, formState: { errors }, reset, watch } = useForm<WithdrawalFormData>({
    defaultValues: {
      amount: 0
    }
  });

  const handleWithdrawalDialogOpen = () => {
    setWithdrawalDialogOpen(true);
    setWithdrawalSuccess(false);
    setWithdrawalError(null);
    reset();
  };

  const handleWithdrawalDialogClose = () => {
    setWithdrawalDialogOpen(false);
    if (withdrawalSuccess) {
      // Refresh wallet data after successful withdrawal
      fetchWalletData();
    }
  };

  const onWithdrawalSubmit = async (data: WithdrawalFormData) => {
    try {
      setWithdrawalLoading(true);
      setWithdrawalError(null);

      if (!walletData) {
        throw new Error("Wallet data not available");
      }

      if (data.amount <= 0) {
        throw new Error("Withdrawal amount must be greater than zero");
      }

      if (data.amount > walletData.balance) {
        throw new Error("Withdrawal amount cannot exceed your available balance");
      }

      // Call the API to request withdrawal
      await api.wallets.requestWithdrawal(data.amount);
      
      // Update state to show success message
      setWithdrawalSuccess(true);
      setWithdrawalAmount(data.amount);
      
      // Update local wallet data to reflect the withdrawal
      setWalletData(prev => {
        if (!prev) return null;
        
        // Create a new transaction for the withdrawal
        const newTransaction = {
          id: `temp-${Date.now()}`,
          wallet_id: prev.id,
          amount: data.amount,
          transaction_type: "debit" as const,
          description: "Withdrawal request",
          status: "pending" as const,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        
        return {
          ...prev,
          balance: prev.balance - data.amount,
          transactions: [newTransaction, ...prev.transactions]
        };
      });
      
      // Show toast notification
      toast.success("Withdrawal request submitted successfully");
    } catch (err: any) {
      console.error("Withdrawal request failed:", err);
      setWithdrawalError(err.message || "Failed to process withdrawal request");
    } finally {
      setWithdrawalLoading(false);
    }
  };

  // Format transaction date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toISOString().split('T')[0]; // Returns YYYY-MM-DD format
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading wallet data...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 text-red-600 rounded-md">
        <h3 className="font-bold">Error</h3>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold">Income Wallet History</h1>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" className="text-success border-success">
            {formatCurrency(totalCredit)} CREDIT
          </Button>
          <Button variant="outline" className="text-red-600 border-red-200">
            {formatCurrency(totalDebit)} DEBIT
          </Button>
          <Button variant="outline" className="text-primary border-primary">
            {formatCurrency(balance)} BALANCE
          </Button>
          <Dialog open={withdrawalDialogOpen} onOpenChange={setWithdrawalDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="bg-primary hover:bg-primary-hover"
                onClick={handleWithdrawalDialogOpen}
              >
                REQUEST WITHDRAWAL
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              {!withdrawalSuccess ? (
                <>
                  <DialogHeader>
                    <DialogTitle>Request Withdrawal</DialogTitle>
                    <DialogDescription>
                      Enter the amount you want to withdraw. The amount must be less than or equal to your available balance of {formatCurrency(balance)}.
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit(onWithdrawalSubmit)}>
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="amount" className="text-right">
                          Amount
                        </Label>
                        <div className="col-span-3">
                          <Input
                            id="amount"
                            type="number"
                            step="0.01"
                            min="1"
                            max={balance}
                            placeholder="Enter amount"
                            className={errors.amount ? "border-red-500" : ""}
                            {...register("amount", {
                              required: "Amount is required",
                              min: {
                                value: 1,
                                message: "Amount must be at least 1"
                              },
                              max: {
                                value: balance,
                                message: `Amount cannot exceed ${formatCurrency(balance)}`
                              },
                              valueAsNumber: true
                            })}
                          />
                          {errors.amount && (
                            <p className="text-red-500 text-sm mt-1">{errors.amount.message}</p>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {withdrawalError && (
                      <div className="bg-red-50 p-3 rounded-md mb-4">
                        <p className="text-red-600 text-sm">{withdrawalError}</p>
                      </div>
                    )}
                    
                    <DialogFooter>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setWithdrawalDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit"
                        disabled={withdrawalLoading}
                      >
                        {withdrawalLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          "Submit Request"
                        )}
                      </Button>
                    </DialogFooter>
                  </form>
                </>
              ) : (
                <>
                  <DialogHeader>
                    <DialogTitle>Withdrawal Requested</DialogTitle>
                  </DialogHeader>
                  
                  <div className="py-6">
                    <Alert className="bg-green-50 border-green-200">
                      <Check className="h-5 w-5 text-green-600" />
                      <AlertTitle className="text-green-800">Success!</AlertTitle>
                      <AlertDescription className="text-green-700">
                        Your withdrawal request for {formatCurrency(withdrawalAmount)} has been submitted successfully.
                        The amount will be sent to your registered bank account within 24 hours.
                      </AlertDescription>
                    </Alert>
                  </div>
                  
                  <DialogFooter>
                    <Button
                      type="button"
                      onClick={handleWithdrawalDialogClose}
                    >
                      Close
                    </Button>
                  </DialogFooter>
                </>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="shadow-card border-0">
        <CardHeader>
          <CardTitle className="text-red-600">Wallet Full Report</CardTitle>
        </CardHeader>
        <CardContent>
          {walletData && walletData.transactions.length > 0 ? (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]">#</TableHead>
                      <TableHead>Credit</TableHead>
                      <TableHead>Debit</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Transfer Status</TableHead>
                      <TableHead>Transfer Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {walletData.transactions
                      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
                      .map((transaction, index) => (
                        <TableRow key={transaction.id}>
                          <TableCell className="font-medium">{index + 1}</TableCell>
                          <TableCell className="font-semibold text-success">
                            {transaction.transaction_type === "credit" 
                              ? formatCurrency(transaction.amount) 
                              : ""}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {transaction.transaction_type === "debit" 
                              ? formatCurrency(transaction.amount) 
                              : "₹0"}
                          </TableCell>
                          <TableCell>{transaction.description || "--"}</TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <div className={`w-2 h-2 rounded-full ${getStatusColor(transaction.status)}`}></div>
                              <span className={getStatusTextColor(transaction.status)}>
                                {capitalizeFirstLetter(transaction.status)}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>{formatDate(transaction.created_at)}</TableCell>
                        </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              <div className="mt-6 pt-4 border-t">
                <div className="grid grid-cols-6 gap-4">
                  <span className="font-semibold">Total</span>
                  <span className="font-semibold text-success">{formatCurrency(totalCredit)}</span>
                  <span className="text-muted-foreground">{formatCurrency(totalDebit)}</span>
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No transactions found in your income wallet.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Helper functions
function getStatusColor(status: string): string {
  switch (status) {
    case "completed":
      return "bg-success";
    case "pending":
      return "bg-yellow-500";
    case "failed":
      return "bg-red-500";
    default:
      return "bg-gray-500";
  }
}

function getStatusTextColor(status: string): string {
  switch (status) {
    case "completed":
      return "text-success font-medium";
    case "pending":
      return "text-yellow-600 font-medium";
    case "failed":
      return "text-red-600 font-medium";
    default:
      return "text-gray-600 font-medium";
  }
}

function capitalizeFirstLetter(string: string): string {
  return string.charAt(0).toUpperCase() + string.slice(1);
}