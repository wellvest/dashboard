import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

// Dummy API data
const investmentData = [
  {
    id: 1,
    name: "MOHD INAM",
    mobile: "9997338564",
    amount: "₹50000",
    returns: "15.0%",
    month: "12",
    status: "Active",
    planDate: "15-12-2024",
    voucherCode: "",
    voucherStatus: "",
    action: "Details"
  }
];

export default function Investment() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">My Investment</h1>
      </div>

      <Card className="shadow-card border-0">
        <CardHeader>
          <CardTitle>Investment Portfolio</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">#</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Mobile</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Returns</TableHead>
                  <TableHead>Month</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Plan Date</TableHead>
                  <TableHead>Voucher Code</TableHead>
                  <TableHead>Voucher Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {investmentData.map((investment, index) => (
                  <TableRow 
                    key={investment.id}
                    className="bg-success-light border-success/20"
                  >
                    <TableCell className="font-medium">{index + 1}</TableCell>
                    <TableCell className="font-medium text-success">
                      {investment.name}
                    </TableCell>
                    <TableCell>{investment.mobile}</TableCell>
                    <TableCell className="font-semibold text-success">
                      {investment.amount}
                    </TableCell>
                    <TableCell className="text-success font-medium">
                      {investment.returns}
                    </TableCell>
                    <TableCell>{investment.month}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-success text-success-foreground">
                        {investment.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{investment.planDate}</TableCell>
                    <TableCell className="text-muted-foreground">-</TableCell>
                    <TableCell className="text-muted-foreground">-</TableCell>
                    <TableCell>
                      <Button variant="secondary" size="sm" className="bg-success text-success-foreground hover:bg-success/90">
                        {investment.action}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}