import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AnimatedButton } from "@/components/ui/animated-button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Eye, Search, ChevronLeft, ChevronRight, Filter, Users } from "lucide-react";
import { useState, useEffect } from "react";
import { NetworkTreeModal } from "@/components/ui/network-tree-modal";
import { motion, AnimatePresence } from "framer-motion";
import { api } from "@/utils/api";
import { useToast } from "@/components/ui/use-toast";

// Status color mapping
const statusColors = {
  "Active": "bg-success",
  "InActive": "bg-red-500",
  "Blocked": "bg-yellow-500"
};

// Default empty state for network data
const emptyNetworkData = {
  summary: {
    downline: "",
    activeCount: 0,
    inactiveCount: 0,
    blockedCount: 0,
    totalCount: 0
  },
  teamMembers: [],
  networkTree: {
    id: "",
    name: "",
    userId: "",
    level: 0,
    status: "Active",
    children: []
  }
};

export default function Network() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [sortBy, setSortBy] = useState("name");
  const [isTreeModalOpen, setIsTreeModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [networkData, setNetworkData] = useState(emptyNetworkData);
  const [filteredMembers, setFilteredMembers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTreeData, setSelectedTreeData] = useState(null);
  
  const itemsPerPage = 4;
  
  // Fetch network data from API
  useEffect(() => {
    const fetchNetworkData = async () => {
      setIsLoading(true);
      try {
        const response = await api.referrals.getNetworkData();
        setNetworkData(response);
        setFilteredMembers(response.teamMembers || []);
        setSelectedTreeData(response.networkTree);
      } catch (error) {
        console.error("Error fetching network data:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load network data. Please try again later."
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchNetworkData();
  }, [toast]);
  
  // Status counts for display
  const statusCounts = {
    "Active": networkData.summary?.activeCount || 0,
    "InActive": networkData.summary?.inactiveCount || 0,
    "Blocked": networkData.summary?.blockedCount || 0
  };
  
  // Apply filters and sorting
  useEffect(() => {
    if (!networkData.teamMembers) return;
    
    setIsLoading(true);
    
    // Apply filters with a small delay for better UX
    const timer = setTimeout(() => {
      let result = [...networkData.teamMembers];
      
      // Apply search filter
      if (searchTerm) {
        result = result.filter(member => 
          member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          member.userId.includes(searchTerm)
        );
      }
      
      // Apply status filter
      if (statusFilter !== "All") {
        result = result.filter(member => member.status === statusFilter);
      }
      
      // Apply sorting
      result.sort((a, b) => {
        if (sortBy === "name") {
          return a.name.localeCompare(b.name);
        } else if (sortBy === "date") {
          return new Date(a.joinDate || 0).getTime() - new Date(b.joinDate || 0).getTime();
        }
        return 0;
      });
      
      setFilteredMembers(result);
      setCurrentPage(1); // Reset to first page when filters change
      setIsLoading(false);
    }, 300);
    
    return () => clearTimeout(timer);
  }, [searchTerm, statusFilter, sortBy, networkData.teamMembers]);
  
  // Pagination logic
  const totalPages = Math.ceil(filteredMembers.length / itemsPerPage);
  const paginatedMembers = filteredMembers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  // Handle page change
  const changePage = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Status Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {Object.entries(statusColors).map(([status, bgColor]) => (
          <motion.div
            key={status}
            className={`${bgColor} text-white rounded-lg shadow-md overflow-hidden`}
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="p-4 text-center">
              <h3 className="text-lg font-medium">{status} Members</h3>
              <p className="text-2xl font-bold mt-2">{statusCounts[status] || 0}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Downline Card */}
      <Card>
        <CardHeader>
          <CardTitle>My Downline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <h3 className="text-sm font-medium text-gray-500">Downline ID</h3>
              <p className="text-lg font-bold">{networkData.summary?.downline || 'N/A'}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-500">Total Referrals</h3>
              <p className="text-lg font-bold">{networkData.summary?.totalCount || 0}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-500">Active Referrals</h3>
              <p className="text-lg font-bold">{networkData.summary?.activeCount || 0}</p>
            </div>
          </div>
          <div className="mt-4 flex justify-center">
            <AnimatedButton 
              variant="default" 
              className="bg-primary hover:bg-primary/90 text-white"
              onClick={() => setIsTreeModalOpen(true)}
            >
              <Eye className="w-4 h-4 mr-2" />
              View Network Tree
            </AnimatedButton>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter Controls */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search by name or ID..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Status</SelectItem>
              <SelectItem value="Active">Active</SelectItem>
              <SelectItem value="InActive">InActive</SelectItem>
              <SelectItem value="Blocked">Blocked</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="amount">Amount</SelectItem>
              <SelectItem value="date">Join Date</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Team Members */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
          </div>
        ) : paginatedMembers.length > 0 ? (
          <AnimatePresence>
            {paginatedMembers.map((member, index) => (
              <motion.div
                key={member.id || index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="shadow-sm border">
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={member.avatar} alt={member.name} />
                          <AvatarFallback>
                            {member.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-bold">{member.name}</h3>
                          <p className="text-sm text-muted-foreground">ID: {member.userId}</p>
                          <Badge variant="secondary" className={`${statusColors[member.status]} text-white mt-1`}>
                            {member.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right ml-auto">
                        <p className="text-xs text-muted-foreground">
                          Joined: {member.joinDate ? new Date(member.joinDate).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        ) : (
          <div className="text-center py-8 border rounded-lg bg-muted/20">
            <Users className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-2 text-lg font-medium">No team members found</h3>
            <p className="text-sm text-muted-foreground">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
      
      {/* Pagination */}
      {filteredMembers.length > 0 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {Math.min((currentPage - 1) * itemsPerPage + 1, filteredMembers.length)} - {Math.min(currentPage * itemsPerPage, filteredMembers.length)} of {filteredMembers.length}
          </p>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => changePage(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <Button
                key={page}
                variant={page === currentPage ? "default" : "outline"}
                size="sm"
                onClick={() => changePage(page)}
                className="w-8 h-8 p-0"
              >
                {page}
              </Button>
            ))}
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => changePage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
      
      {/* Network Tree Modal */}
      <NetworkTreeModal 
        isOpen={isTreeModalOpen}
        onClose={() => setIsTreeModalOpen(false)}
        rootNode={selectedTreeData}
      />
    </div>
  );
}