import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShoppingBag, Calendar, Clock, Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";
import { format } from "date-fns";
import { useToast } from "@/components/ui/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { api } from "@/utils/api";
import { useAuth } from "@/contexts/AuthContext";

interface ShoppingVoucher {
  id: string;
  code: string;
  amount: number;
  is_used: boolean;
  expiry_date: string;
  created_at: string;
  used_at: string | null;
}

export default function ShoppingVoucher() {
  const [vouchers, setVouchers] = useState<ShoppingVoucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const fetchVouchers = async () => {
      if (!isAuthenticated) return;
      
      try {
        setLoading(true);
        const data = await api.wallets.getShoppingVouchers();
        setVouchers(data);
      } catch (err) {
        console.error("Failed to fetch vouchers:", err);
        setError("Failed to load vouchers. Please try again later.");
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load vouchers. Please try again later.",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchVouchers();
  }, [toast, isAuthenticated]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Shopping Voucher</h1>
        </div>
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <Card key={i} className="shadow-card border-0">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div className="space-y-2">
                    <Skeleton className="h-6 w-32" />
                    <Skeleton className="h-4 w-48" />
                  </div>
                  <Skeleton className="h-10 w-24" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Shopping Voucher</h1>
      </div>

      {error ? (
        <Card className="shadow-card border-0">
          <CardContent className="p-6 text-center">
            <div className="flex flex-col items-center space-y-4">
              <div className="p-4 rounded-full bg-destructive/10">
                <X className="h-8 w-8 text-destructive" />
              </div>
              <p className="text-muted-foreground">{error}</p>
            </div>
          </CardContent>
        </Card>
      ) : vouchers.length === 0 ? (
        <Card className="shadow-card border-0">
          <CardContent className="p-12 text-center">
            <div className="flex flex-col items-center space-y-4">
              <div className="p-6 rounded-full bg-muted">
                <ShoppingBag className="h-12 w-12 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-muted-foreground">
                No Shopping Vouchers Available
              </h3>
              <p className="text-muted-foreground">
                Your shopping vouchers will appear here once they are available.
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {vouchers.map((voucher) => (
            <Card key={voucher.id} className="shadow-card border-0">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <h3 className="text-lg font-semibold">Code: {voucher.code}</h3>
                      <Badge variant={voucher.is_used ? "outline" : "default"}>
                        {voucher.is_used ? "Used" : "Available"}
                      </Badge>
                    </div>
                    <div className="flex space-x-4 text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <Calendar className="mr-1 h-4 w-4" />
                        <span>Expires: {voucher.expiry_date ? format(new Date(voucher.expiry_date), "MMM d, yyyy") : "No expiry"}</span>
                      </div>
                      {voucher.is_used && voucher.used_at && (
                        <div className="flex items-center">
                          <Clock className="mr-1 h-4 w-4" />
                          <span>Used on: {format(new Date(voucher.used_at), "MMM d, yyyy")}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-xl font-bold">
                    {formatCurrency(voucher.amount)}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}