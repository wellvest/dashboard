import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Edit, Save, X } from "lucide-react";
import { AvatarUpload } from "@/components/ui/avatar-upload";
import { toast } from "sonner";
import { useUserData } from "@/contexts/UserDataContext";
import { useAuth } from "@/contexts/AuthContext";
import { api } from "@/utils/api";
import { ReferralCard } from "@/components/profile/ReferralCard";

// Define a combined user form data type
interface UserFormData {
  name: string;
  email: string;
  phone: string;
  date_of_birth: string;
  gender: string;
  member_id: string;
  avatar?: string;
  plan_amount: number;
  kyc_verified: boolean;
}

export default function Profile() {
  const { userData, updateProfile, fetchUserData } = useUserData();
  const { user, refreshUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<UserFormData>({} as UserFormData);
  const [isSaving, setIsSaving] = useState(false);


  // Initialize form data from user and profile
  useEffect(() => {
    if (user && userData.profile) {
      setFormData({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        date_of_birth: user.date_of_birth || "",
        gender: user.gender || "",
        member_id: user.member_id || "",
        avatar: user.avatar || "",
        plan_amount: userData.profile?.plan_amount || 0,
        kyc_verified: userData.profile?.kyc_verified || false
      });
    }
  }, [user, userData.profile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleAvatarUpdate = (newAvatarUrl: string) => {
    setFormData(prev => ({
      ...prev,
      avatar: newAvatarUrl
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      
      // Always update profile data via API regardless of whether profile exists or not
      // The backend will create a profile if it doesn't exist
      await updateProfile({
        plan_amount: formData.plan_amount,
        kyc_verified: formData.kyc_verified
      });
      
      // Update user data if changed
      const userUpdateData = {
        name: formData.name !== user?.name ? formData.name : undefined,
        email: formData.email !== user?.email ? formData.email : undefined,
        phone: formData.phone !== user?.phone ? formData.phone : undefined,
        date_of_birth: formData.date_of_birth !== user?.date_of_birth ? formData.date_of_birth : undefined,
        gender: formData.gender !== user?.gender ? formData.gender : undefined,
      };
      
      // Only send update if there are changes
      if (Object.values(userUpdateData).some(val => val !== undefined)) {
        await api.user.update(userUpdateData);
      }
      
      // Refresh user data from API to get the latest changes
      await refreshUser();
      await fetchUserData(); // Refresh profile data too
      
      setIsSaving(false);
      setIsEditing(false);
      toast.success("Profile updated successfully");
    } catch (error) {
      console.error("Error updating profile:", error);
      toast.error("Failed to update profile");
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    // Reset form data to current user and profile data
    if (user && userData.profile) {
      setFormData({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        date_of_birth: user.date_of_birth || "",
        gender: user.gender || "",
        member_id: user.member_id || "",
        avatar: user.avatar || "",
        plan_amount: userData.profile?.plan_amount || 0,
        kyc_verified: userData.profile?.kyc_verified || false
      });
    }
    setIsEditing(false);
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-navy-header">My Profile</h1>
          <p className="text-muted-foreground mt-1">Manage your personal information</p>
        </div>
        {isEditing ? (
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleCancel} disabled={isSaving}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        ) : (
          <Button onClick={() => setIsEditing(true)}>
            <Edit className="w-4 h-4 mr-2" />
            Edit Profile
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Picture Card */}
        <Card className="shadow-card border border-gray-100/80 bg-gradient-card overflow-hidden">
          <div className="h-16 bg-gradient-primary"></div>
          <CardContent className="p-6 text-center -mt-8">
            <div className="relative inline-block">
              <AvatarUpload
                currentAvatarUrl={formData.avatar}
                userName={formData.name || 'User'}
                onAvatarUpdate={handleAvatarUpdate}
                size="xl"
                className="mx-auto mb-4"
                editable={isEditing}
              />
            </div>
            <h2 className="text-xl font-bold mb-1">{formData.name}</h2>
            <p className="text-muted-foreground">ID: {formData.member_id}</p>
            <div className="mt-4 p-3 bg-gradient-success/10 rounded-lg border border-success/10">
              <p className="text-success font-semibold">Plan: ₹{formData.plan_amount?.toFixed(2)}</p>
            </div>
          </CardContent>
        </Card>
        
        {/* Referral Card */}
        <ReferralCard />

        {/* Profile Information */}
        <Card className="lg:col-span-2 shadow-card border border-gray-100/80 bg-gradient-card">
          <CardHeader className="border-b border-gray-100/80 bg-white/50">
            <CardTitle className="text-navy-header flex items-center gap-2">
              <div className="h-5 w-1 bg-accent rounded-full"></div>
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input 
                  id="name" 
                  value={formData.name || ''} 
                  onChange={handleChange}
                  readOnly={!isEditing} 
                  className={`mt-2 ${!isEditing ? 'bg-muted' : ''}`} 
                />
              </div>
              
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input 
                  id="email" 
                  value={formData.email || ''} 
                  onChange={handleChange}
                  readOnly={!isEditing} 
                  className={`mt-2 ${!isEditing ? 'bg-muted' : ''}`} 
                />
              </div>
              
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input 
                  id="phone" 
                  value={formData.phone || ''} 
                  onChange={handleChange}
                  readOnly={!isEditing} 
                  className={`mt-2 ${!isEditing ? 'bg-muted' : ''}`} 
                />
              </div>
              
              <div>
                <Label htmlFor="dob">Date of Birth</Label>
                <Input 
                  id="date_of_birth" 
                  value={formData.date_of_birth || ''} 
                  onChange={handleChange}
                  readOnly={!isEditing} 
                  className={`mt-2 ${!isEditing ? 'bg-muted' : ''}`} 
                />
              </div>
              
              <div>
                <Label htmlFor="gender">Gender</Label>
                <Input 
                  id="gender" 
                  value={formData.gender || ''} 
                  onChange={handleChange}
                  readOnly={!isEditing} 
                  className={`mt-2 ${!isEditing ? 'bg-muted' : ''}`} 
                />
              </div>
              

              
              <div className="md:col-span-2">
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    value={userData.addresses && userData.addresses.length > 0 ? 
                      `${userData.addresses[0].address_line1}, ${userData.addresses[0].city}, ${userData.addresses[0].state}` : 
                      'No address on file'}
                    className="mt-2"
                    disabled={true}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}