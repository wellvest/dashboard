import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Calendar, CheckCircle, Clock, AlertCircle, ChevronRight, UserPlus, Trophy } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function TeamPlan() {
  // Placeholder data for future implementation
  const launchDate = "August 15, 2025";
  const features = [
    { icon: UserPlus, text: "Invite team members to join your investment plan" },
    { icon: Trophy, text: "Earn additional bonuses based on team performance" },
    { icon: CheckCircle, text: "Track team investments and returns in real-time" },
    { icon: Calendar, text: "Schedule team investment meetings and goals" }
  ];
  
  return (
    <div className="space-y-8 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-navy-header">My Team Plan</h1>
        <span className="px-2 py-1 text-xs bg-amber-100 text-amber-600 rounded-full font-medium border border-amber-200">
          Coming Soon
        </span>
      </div>

      {/* Main Coming Soon Card */}
      <Card className="shadow-card border-0 overflow-hidden bg-white">
        <CardHeader className="pb-2 bg-gradient-primary/10 border-b">
          <CardTitle className="text-xl text-primary flex items-center gap-2">
            <Users className="h-5 w-5" /> Team Investment Plan
          </CardTitle>
          <CardDescription className="text-sm font-medium text-navy-header">
            Collaborate with your team and maximize your investment returns
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Left side - Coming Soon Message */}
            <div className="flex-1 flex flex-col items-center text-center space-y-6 p-4 bg-gradient-primary/5 rounded-lg">
              <div className="p-4 rounded-full bg-gradient-primary/10 ring-4 ring-primary/5">
                <Users className="h-12 w-12 text-primary" />
              </div>
              
              <h2 className="text-2xl font-bold text-navy-header">
                Team Plan Coming Soon
              </h2>
              
              <div className="flex items-center gap-2 text-amber-600 bg-amber-50 px-4 py-2 rounded-full border border-amber-100">
                <Clock className="h-4 w-4" />
                <span className="font-medium">Launching Soon</span>
              </div>
              
              <p className="text-navy-text max-w-md">
                We're working hard to bring you an exciting new feature that will allow you to create and manage team investment plans. Stay tuned for updates!
              </p>
              
              <div className="w-full max-w-md space-y-2">
                <div className="flex justify-between text-sm font-medium">
                  <span>Development Progress</span>
                  <span>75%</span>
                </div>
                <Progress value={75} className="h-2" />
              </div>
            </div>
            
            {/* Right side - Feature Preview */}
            <div className="flex-1 space-y-6">
              <h3 className="font-semibold text-lg border-b pb-2 text-navy-header">Upcoming Features</h3>
              <div className="space-y-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 rounded-md hover:bg-gradient-primary/5 transition-colors">
                    <div className="p-2 rounded-full bg-gradient-primary/10 text-primary">
                      <feature.icon size={18} />
                    </div>
                    <p className="text-navy-text">{feature.text}</p>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 border border-amber-200 bg-amber-50 rounded-md">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-700">Want early access?</h4>
                    <p className="text-sm text-amber-600">Contact our support team to join the beta testing program.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}