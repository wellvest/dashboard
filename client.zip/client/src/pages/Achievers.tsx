import { Card, CardContent } from "@/components/ui/card";
import { Lock, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Achievers() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">My Achievers Group</h1>
        <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">
          Coming Soon
        </Badge>
      </div>

      <Card className="shadow-card border-0 relative overflow-hidden">
        {/* Overlay to lock the content */}
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center">
          <Lock className="h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold text-primary mb-2">Coming Soon</h2>
          <p className="text-muted-foreground text-center max-w-md px-4">
            The Achievers Group feature is currently under development and will be available soon.
          </p>
        </div>
        
        {/* Blurred background content */}
        <CardContent className="p-12 text-center blur-sm">
          <div className="flex flex-col items-center space-y-4">
            <div className="p-6 rounded-full bg-muted">
              <Clock className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-muted-foreground">
              Achievers Group
            </h3>
            <p className="text-muted-foreground">
              Track your team's achievements and milestones in real-time.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}