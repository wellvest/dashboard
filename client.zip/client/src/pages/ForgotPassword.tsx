import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/ui/logo";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { Eye, EyeOff, ArrowRight, Check, ArrowLeft } from "lucide-react";
import api from "@/utils/api";

export default function ForgotPassword() {
  const [step, setStep] = useState<"phone" | "otp" | "reset">("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Countdown timer for OTP resend
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleSendOtp = async () => {
    if (!phone) {
      toast({
        variant: "destructive",
        title: "Phone number required",
        description: "Please enter your phone number.",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      await api.auth.forgotPassword({ phone });
      
      setStep("otp");
      setCountdown(60); // 60 seconds countdown for resend
      
      toast({
        title: "OTP sent",
        description: "A verification code has been sent to your phone.",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Failed to send OTP",
        description: error.data?.detail || "Please check your phone number and try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleVerifyOtp = async () => {
    if (!otp) {
      toast({
        variant: "destructive",
        title: "OTP required",
        description: "Please enter the verification code sent to your phone.",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      await api.auth.verifyOTP({
        phone,
        otp
      });
      
      setStep("reset");
      
      toast({
        title: "OTP verified",
        description: "Please set your new password.",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "OTP verification failed",
        description: error.data?.detail || "Invalid or expired OTP. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleResetPassword = async () => {
    if (!newPassword || !confirmPassword) {
      toast({
        variant: "destructive",
        title: "Password required",
        description: "Please enter and confirm your new password.",
      });
      return;
    }
    
    if (newPassword.length < 8) {
      toast({
        variant: "destructive",
        title: "Password too short",
        description: "Password must be at least 8 characters long.",
      });
      return;
    }
    
    if (newPassword !== confirmPassword) {
      toast({
        variant: "destructive",
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      await api.auth.resetPasswordWithOTP({
        phone,
        otp,
        new_password: newPassword,
        confirm_password: confirmPassword
      });
      
      toast({
        title: "Password reset successful",
        description: "Your password has been reset. You can now log in with your new password.",
      });
      
      navigate("/login");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Password reset failed",
        description: error.data?.detail || "Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderPhoneStep = () => (
    <>
      <h1 className="text-2xl font-bold text-center mb-2">Forgot Password</h1>
      <p className="text-muted-foreground text-center mb-6">
        Enter your phone number to reset your password
      </p>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            type="tel"
            placeholder="Enter your phone number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
            autoComplete="tel"
            className="h-11"
          />
        </div>
        
        <Button 
          type="button" 
          className="w-full h-11" 
          onClick={handleSendOtp}
          disabled={isLoading || !phone}
        >
          {isLoading ? (
            <div className="flex items-center">
              <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              Sending OTP...
            </div>
          ) : (
            <div className="flex items-center">
              Continue
              <ArrowRight className="ml-2 h-4 w-4" />
            </div>
          )}
        </Button>
      </div>
    </>
  );
  
  const renderOtpStep = () => (
    <>
      <h1 className="text-2xl font-bold text-center mb-2">Verify OTP</h1>
      <p className="text-muted-foreground text-center mb-6">
        Enter the verification code sent to your phone
      </p>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="otp">Verification Code</Label>
          <Input
            id="otp"
            type="text"
            placeholder="Enter 6-digit code"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            required
            className="h-11"
            maxLength={6}
          />
          <div className="flex justify-between items-center">
            <p className="text-xs text-muted-foreground">
              Didn't receive the code?
            </p>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleSendOtp}
              disabled={countdown > 0 || isLoading}
              className="h-8 text-xs"
            >
              {countdown > 0 ? `Resend in ${countdown}s` : "Resend OTP"}
            </Button>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            type="button" 
            variant="outline"
            className="flex-1 h-11" 
            onClick={() => setStep("phone")}
            disabled={isLoading}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          
          <Button 
            type="button" 
            className="flex-1 h-11" 
            onClick={handleVerifyOtp}
            disabled={isLoading || !otp || otp.length < 6}
          >
            {isLoading ? (
              <div className="flex items-center">
                <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Verifying...
              </div>
            ) : (
              <div className="flex items-center">
                Continue
                <ArrowRight className="ml-2 h-4 w-4" />
              </div>
            )}
          </Button>
        </div>
      </div>
    </>
  );
  
  const renderResetStep = () => (
    <>
      <h1 className="text-2xl font-bold text-center mb-2">Reset Password</h1>
      <p className="text-muted-foreground text-center mb-6">
        Create a new password for your account
      </p>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="newPassword">New Password</Label>
          <div className="relative">
            <Input
              id="newPassword"
              type={showPassword ? "text" : "password"}
              placeholder="••••••••"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
              className="h-11 pr-10"
            />
            <button
              type="button"
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={() => setShowPassword(!showPassword)}
              tabIndex={-1}
            >
              {showPassword ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Must be at least 8 characters long
          </p>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="confirmPassword">Confirm Password</Label>
          <Input
            id="confirmPassword"
            type={showPassword ? "text" : "password"}
            placeholder="••••••••"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            className="h-11"
          />
        </div>
        
        <Button 
          type="button" 
          className="w-full h-11" 
          onClick={handleResetPassword}
          disabled={isLoading || !newPassword || !confirmPassword}
        >
          {isLoading ? (
            <div className="flex items-center">
              <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              Resetting Password...
            </div>
          ) : (
            <div className="flex items-center">
              Reset Password
              <Check className="ml-2 h-4 w-4" />
            </div>
          )}
        </Button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="bg-card rounded-xl shadow-lg p-8 border border-border">
          <div className="flex justify-center mb-6">
            <Logo size="lg" variant="full" />
          </div>
          
          {step === "phone" && renderPhoneStep()}
          {step === "otp" && renderOtpStep()}
          {step === "reset" && renderResetStep()}
          
          <div className="mt-6 text-center text-sm text-muted-foreground">
            Remember your password?{" "}
            <Link to="/login" className="text-primary font-medium hover:underline">
              Sign in
            </Link>
          </div>
        </div>
        
        <p className="text-center text-xs text-muted-foreground mt-4">
          © {new Date().getFullYear()} WellVest. All rights reserved.
        </p>
      </motion.div>
    </div>
  );
}
