import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import AdminLayout from "@/components/layout/AdminLayout";
import axios from "axios";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { CheckCircle2, XCircle, Eye, Loader2 } from "lucide-react";

// Define types
interface User {
  id: string;
  name: string;
  email: string;
  member_id: string;
}

interface Profile {
  id: string;
  user_id: string;
  kyc_verified: boolean;
  kyc_document_type: string;
  kyc_document_number: string;
  kyc_document_url: string;
}

interface UserProfile {
  user: User;
  profile: Profile;
}

export default function KYCVerification() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Get user ID from query parameters if present
  const queryParams = new URLSearchParams(location.search);
  const userIdFilter = queryParams.get('user');

  // Check if user is admin
  useEffect(() => {
    if (user && !user.email.endsWith('@admin.wellvest.com')) {
      navigate('/dashboard');
    } else {
      fetchUsers();
    }
  }, [user, navigate]);

  // Fetch all users with their profiles
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/admin/users');
      // Filter only users with KYC documents
      let usersWithKYC = response.data.filter(
        (user: UserProfile) => user.profile && user.profile.kyc_document_url
      );
      
      // If userIdFilter is present, filter to show only that user
      if (userIdFilter) {
        usersWithKYC = usersWithKYC.filter(
          (userProfile: UserProfile) => userProfile.user.id === userIdFilter
        );
        
        // If we have exactly one user and it matches the filter, open the dialog
        if (usersWithKYC.length === 1) {
          setTimeout(() => {
            handleViewKYC(usersWithKYC[0]);
          }, 500);
        }
      }
      
      setUsers(usersWithKYC);
    } catch (error) {
      console.error('Failed to fetch users:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  // Handle view KYC details
  const handleViewKYC = (userProfile: UserProfile) => {
    setSelectedUser(userProfile);
    setIsDialogOpen(true);
  };

  // Handle KYC verification
  const handleVerifyKYC = async (userId: string, verified: boolean) => {
    try {
      setIsProcessing(true);
      await axios.put(`/api/admin/users/${userId}/kyc-verify`, { verified });
      
      // Update local state
      setUsers(prevUsers => 
        prevUsers.map(userProfile => {
          if (userProfile.user.id === userId && userProfile.profile) {
            return {
              ...userProfile,
              profile: {
                ...userProfile.profile,
                kyc_verified: verified
              }
            };
          }
          return userProfile;
        })
      );
      
      // Close dialog
      setIsDialogOpen(false);
      setSelectedUser(null);
      
      toast.success(`KYC ${verified ? 'approved' : 'rejected'} successfully`);
    } catch (error) {
      console.error('Failed to verify KYC:', error);
      toast.error('Failed to process KYC verification');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <AdminLayout>
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">KYC Verification</h1>
          <p className="text-muted-foreground">Verify user KYC documents</p>
        </div>
        <Button 
          variant="outline" 
          onClick={fetchUsers}
          disabled={loading}
        >
          {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
          Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Pending Verifications</CardTitle>
          <CardDescription>
            Review and approve or reject KYC documents submitted by users
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : users.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No pending KYC verifications found
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Document Type</TableHead>
                  <TableHead>Document Number</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((userProfile) => (
                  <TableRow key={userProfile.user.id}>
                    <TableCell className="font-mono text-xs">
                      {userProfile.user.member_id}
                    </TableCell>
                    <TableCell>{userProfile.user.name}</TableCell>
                    <TableCell>{userProfile.profile?.kyc_document_type || 'N/A'}</TableCell>
                    <TableCell>{userProfile.profile?.kyc_document_number || 'N/A'}</TableCell>
                    <TableCell>
                      {userProfile.profile?.kyc_verified ? (
                        <Badge className="bg-green-500">Verified</Badge>
                      ) : (
                        <Badge className="bg-amber-500">Pending</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewKYC(userProfile)}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* KYC Details Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>KYC Document Verification</DialogTitle>
            <DialogDescription>
              Review the document details and approve or reject the KYC submission
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">User Details</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Name:</span>
                      <span>{selectedUser.user.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Email:</span>
                      <span>{selectedUser.user.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Member ID:</span>
                      <span className="font-mono">{selectedUser.user.member_id}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Document Details</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Document Type:</span>
                      <span>{selectedUser.profile?.kyc_document_type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Document Number:</span>
                      <span>{selectedUser.profile?.kyc_document_number}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <span>
                        {selectedUser.profile?.kyc_verified ? (
                          <Badge className="bg-green-500">Verified</Badge>
                        ) : (
                          <Badge className="bg-amber-500">Pending</Badge>
                        )}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg overflow-hidden">
                <div className="bg-muted p-2 text-sm font-medium">Document Image</div>
                <div className="p-4 flex justify-center">
                  <img 
                    src={selectedUser.profile?.kyc_document_url} 
                    alt="KYC Document" 
                    className="max-h-[400px] object-contain"
                  />
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex justify-between items-center">
            <div className="text-sm text-muted-foreground">
              {selectedUser?.profile?.kyc_verified 
                ? "This document has already been verified." 
                : "Please review the document carefully before verification."}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                disabled={isProcessing}
              >
                Close
              </Button>
              {!selectedUser?.profile?.kyc_verified && (
                <>
                  <Button
                    variant="destructive"
                    onClick={() => selectedUser && handleVerifyKYC(selectedUser.user.id, false)}
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <XCircle className="h-4 w-4 mr-2" />
                    )}
                    Reject
                  </Button>
                  <Button
                    variant="default"
                    onClick={() => selectedUser && handleVerifyKYC(selectedUser.user.id, true)}
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                    )}
                    Approve
                  </Button>
                </>
              )}
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
    </AdminLayout>
  );
}
