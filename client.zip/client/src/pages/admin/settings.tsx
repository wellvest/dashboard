import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import AdminLayout from "@/components/layout/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Loader2, Save } from "lucide-react";

export default function AdminSettings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  
  // General settings
  const [siteName, setSiteName] = useState("WellVest");
  const [siteDescription, setSiteDescription] = useState("Investment platform for everyone");
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  
  // KYC settings
  const [kycEnabled, setKycEnabled] = useState(true);
  const [kycRequiredForInvestment, setKycRequiredForInvestment] = useState(true);
  const [kycDocumentTypes, setKycDocumentTypes] = useState("Aadhar Card, PAN Card, Passport");
  
  // Email settings
  const [emailFrom, setEmailFrom] = useState("noreply@wellvest.com");
  const [emailReplyTo, setEmailReplyTo] = useState("support@wellvest.com");
  const [emailNotifications, setEmailNotifications] = useState(true);
  
  const handleSaveSettings = async (tab: string) => {
    setLoading(true);
    
    try {
      // In a real app, this would be an API call to save settings
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success(`${tab} settings saved successfully`);
    } catch (error) {
      console.error('Failed to save settings:', error);
      toast.error('Failed to save settings');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Admin Settings</h1>
          <p className="text-muted-foreground">Configure system settings and preferences</p>
        </div>
        
        <Tabs defaultValue="general">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="kyc">KYC</TabsTrigger>
            <TabsTrigger value="email">Email</TabsTrigger>
          </TabsList>
          
          {/* General Settings */}
          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>
                  Configure basic site settings and functionality
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="site-name">Site Name</Label>
                    <Input 
                      id="site-name" 
                      value={siteName} 
                      onChange={(e) => setSiteName(e.target.value)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="site-description">Site Description</Label>
                    <Input 
                      id="site-description" 
                      value={siteDescription} 
                      onChange={(e) => setSiteDescription(e.target.value)} 
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="maintenance-mode" 
                      checked={maintenanceMode}
                      onCheckedChange={setMaintenanceMode}
                    />
                    <Label htmlFor="maintenance-mode">Maintenance Mode</Label>
                  </div>
                </div>
                
                <Button 
                  onClick={() => handleSaveSettings('General')}
                  disabled={loading}
                >
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                  Save Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* KYC Settings */}
          <TabsContent value="kyc">
            <Card>
              <CardHeader>
                <CardTitle>KYC Settings</CardTitle>
                <CardDescription>
                  Configure KYC verification requirements and options
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="kyc-enabled" 
                      checked={kycEnabled}
                      onCheckedChange={setKycEnabled}
                    />
                    <Label htmlFor="kyc-enabled">Enable KYC Verification</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="kyc-required" 
                      checked={kycRequiredForInvestment}
                      onCheckedChange={setKycRequiredForInvestment}
                      disabled={!kycEnabled}
                    />
                    <Label htmlFor="kyc-required">Require KYC for Investments</Label>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="kyc-document-types">Allowed Document Types</Label>
                    <Input 
                      id="kyc-document-types" 
                      value={kycDocumentTypes} 
                      onChange={(e) => setKycDocumentTypes(e.target.value)}
                      disabled={!kycEnabled}
                    />
                    <p className="text-xs text-muted-foreground">Comma-separated list of allowed document types</p>
                  </div>
                </div>
                
                <Button 
                  onClick={() => handleSaveSettings('KYC')}
                  disabled={loading}
                >
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                  Save Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Email Settings */}
          <TabsContent value="email">
            <Card>
              <CardHeader>
                <CardTitle>Email Settings</CardTitle>
                <CardDescription>
                  Configure email notifications and sender information
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email-from">From Email</Label>
                    <Input 
                      id="email-from" 
                      value={emailFrom} 
                      onChange={(e) => setEmailFrom(e.target.value)} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email-reply-to">Reply-To Email</Label>
                    <Input 
                      id="email-reply-to" 
                      value={emailReplyTo} 
                      onChange={(e) => setEmailReplyTo(e.target.value)} 
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="email-notifications" 
                      checked={emailNotifications}
                      onCheckedChange={setEmailNotifications}
                    />
                    <Label htmlFor="email-notifications">Enable Email Notifications</Label>
                  </div>
                </div>
                
                <Button 
                  onClick={() => handleSaveSettings('Email')}
                  disabled={loading}
                >
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                  Save Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}
