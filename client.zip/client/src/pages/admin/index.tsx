import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import AdminLayout from "@/components/layout/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, Users, FileCheck, ArrowUpRight, Loader2 } from "lucide-react";
import axios from "axios";
import { toast } from "sonner";

interface DashboardStats {
  totalUsers: number;
  pendingKYC: number;
  totalInvestments: number;
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    pendingKYC: 0,
    totalInvestments: 0
  });
  const [loading, setLoading] = useState(true);

  // Check if user is admin
  useEffect(() => {
    if (user && !user.email.endsWith('@admin.wellvest.com')) {
      navigate('/dashboard');
    } else if (user) {
      fetchDashboardStats();
    }
  }, [user, navigate]);
  
  // Fetch dashboard statistics
  const fetchDashboardStats = async () => {
    try {
      setLoading(true);
      
      // Get all users to calculate stats
      const usersResponse = await axios.get('/api/admin/users');
      const users = usersResponse.data;
      
      // Calculate statistics
      const totalUsers = users.length;
      const pendingKYC = users.filter(u => 
        u.profile && u.profile.kyc_document_url && !u.profile.kyc_verified
      ).length;
      
      // For demo purposes, calculate a mock investment total
      // In a real app, this would come from a separate API endpoint
      const totalInvestments = users.reduce((sum, user) => {
        return sum + (user.profile?.plan_amount || 0);
      }, 0);
      
      setStats({
        totalUsers,
        pendingKYC,
        totalInvestments
      });
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error);
      toast.error('Failed to load dashboard statistics');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Welcome to the WellVest admin panel</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                ) : (
                  <div className="text-2xl font-bold">{stats.totalUsers}</div>
                )}
                <Users className="h-5 w-5 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending KYC</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                ) : (
                  <div className="text-2xl font-bold">{stats.pendingKYC}</div>
                )}
                <FileCheck className="h-5 w-5 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Investments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                {loading ? (
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                ) : (
                  <div className="text-2xl font-bold">₹{(stats.totalInvestments / 1000000).toFixed(1)}M</div>
                )}
                <BarChart3 className="h-5 w-5 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div 
                className="p-4 border rounded-lg flex items-center justify-between cursor-pointer hover:bg-gray-50"
                onClick={() => navigate('/admin/kyc-verification')}
              >
                <div>
                  <h3 className="font-medium">KYC Verification</h3>
                  <p className="text-sm text-muted-foreground">Review and approve user documents</p>
                </div>
                <ArrowUpRight className="h-5 w-5 text-muted-foreground" />
              </div>
              
              <div 
                className="p-4 border rounded-lg flex items-center justify-between cursor-pointer hover:bg-gray-50"
                onClick={() => navigate('/admin/users')}
              >
                <div>
                  <h3 className="font-medium">User Management</h3>
                  <p className="text-sm text-muted-foreground">View and manage user accounts</p>
                </div>
                <ArrowUpRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
