import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import AdminLayout from "@/components/layout/AdminLayout";
import axios from "axios";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Search, Loader2, UserCheck, UserX } from "lucide-react";

// Define types
interface User {
  id: string;
  name: string;
  email: string;
  member_id: string;
  is_active: boolean;
  avatar?: string;
}

interface Profile {
  id: string;
  user_id: string;
  kyc_verified: boolean;
  kyc_document_type: string;
  kyc_document_number: string;
  kyc_document_url: string;
}

interface UserProfile {
  user: User;
  profile: Profile;
}

export default function UserManagement() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredUsers, setFilteredUsers] = useState<UserProfile[]>([]);

  // Check if user is admin
  useEffect(() => {
    if (user && !user.email.endsWith('@admin.wellvest.com')) {
      navigate('/dashboard');
    } else {
      fetchUsers();
    }
  }, [user, navigate]);

  // Fetch all users
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/admin/users');
      setUsers(response.data);
      setFilteredUsers(response.data);
    } catch (error) {
      console.error('Failed to fetch users:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  // Filter users based on search query
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredUsers(users);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = users.filter(
      (userProfile) => 
        userProfile.user.name.toLowerCase().includes(query) ||
        userProfile.user.email.toLowerCase().includes(query) ||
        userProfile.user.member_id.toLowerCase().includes(query)
    );
    
    setFilteredUsers(filtered);
  }, [searchQuery, users]);

  // Navigate to KYC verification page for a specific user
  const viewUserKYC = (userId: string) => {
    navigate(`/admin/kyc-verification?user=${userId}`);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">User Management</h1>
            <p className="text-muted-foreground">View and manage all users</p>
          </div>
          <Button 
            variant="outline" 
            onClick={fetchUsers}
            disabled={loading}
          >
            {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
            Refresh
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All Users</CardTitle>
            <CardDescription>
              Total users: {users.length}
            </CardDescription>
            <div className="relative mt-4">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, email or member ID..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {searchQuery ? "No users match your search" : "No users found"}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Member ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Join Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>KYC Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((userProfile) => (
                      <TableRow key={userProfile.user.id}>
                        <TableCell className="font-mono text-xs">
                          {userProfile.user.member_id}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={userProfile.user.avatar || ''} alt={userProfile.user.name} />
                              <AvatarFallback>
                                {userProfile.user.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                            <span>{userProfile.user.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>{userProfile.user.email}</TableCell>
                        <TableCell>
                          {userProfile.profile?.join_date 
                            ? new Date(userProfile.profile.join_date).toLocaleDateString() 
                            : 'N/A'}
                        </TableCell>
                        <TableCell>
                          {userProfile.user.is_active ? (
                            <Badge className="bg-green-500">Active</Badge>
                          ) : (
                            <Badge className="bg-red-500">Inactive</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {userProfile.profile?.kyc_verified ? (
                            <Badge className="bg-green-500 flex items-center w-fit">
                              <UserCheck className="h-3 w-3 mr-1" />
                              Verified
                            </Badge>
                          ) : userProfile.profile?.kyc_document_url ? (
                            <Badge className="bg-amber-500 flex items-center w-fit">
                              Pending
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-500 flex items-center w-fit">
                              <UserX className="h-3 w-3 mr-1" />
                              Not Submitted
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => viewUserKYC(userProfile.user.id)}
                            disabled={!userProfile.profile?.kyc_document_url}
                          >
                            View KYC
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
