import { Card, CardContent } from "@/components/ui/card";
import { ShoppingCart } from "lucide-react";

export default function ShoppingWallet() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">I-Shopping Wallet</h1>
      </div>

      <Card className="shadow-card border-0">
        <CardContent className="p-12 text-center">
          <div className="flex flex-col items-center space-y-4">
            <div className="p-6 rounded-full bg-muted">
              <ShoppingCart className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-muted-foreground">
              Shopping Wallet Empty
            </h3>
            <p className="text-muted-foreground">
              Your shopping wallet balance and transactions will appear here.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}