import React, { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useAuth, Profile } from "@/contexts/AuthContext";
import { CheckCircle, ArrowRight, AlertCircle, ChevronRight } from "lucide-react";
import axios from "axios";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { api } from "@/utils/api";

// API URL configuration
const API_URL = import.meta.env.VITE_API_URL || '';

interface Plan {
  id: string;
  name: string;
  min_amount: number;
  max_amount: number;
  returns_percentage: number;
  duration_months: number;
}

// Extended profile type to include additional fields for the table view
interface ExtendedProfile extends Profile {
  phone?: string;
  plan_date?: string;
  voucher_code?: string;
  voucher_status?: string;
}

export default function MyPlan() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const { toast } = useToast();
  const { user, profile: authProfile } = useAuth();
  
  // Cast profile to ExtendedProfile and add user properties for the table view
  const profile: ExtendedProfile = authProfile ? {
    ...authProfile,
    phone: user?.phone,
    plan_date: "2024-12-16", // Example date for demonstration
    voucher_code: "—",
    voucher_status: "—"
  } : null;

  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const response = await axios.get(`${API_URL}/api/plans`);
        setPlans(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching plans:", error);
        toast({
          title: "Error",
          description: "Failed to load investment plans. Please try again.",
          variant: "destructive",
        });
        setLoading(false);
      }
    };

    fetchPlans();
  }, [toast]);

  const handleSelectPlan = async (plan: Plan) => {
    try {
      // Calculate a default investment amount based on the plan's minimum amount
      const investmentAmount = plan.min_amount;
      
      // Create an investment through the API
      const response = await axios.post(`${API_URL}/api/investments`, {
        plan_id: plan.id,
        amount: investmentAmount,
        duration_months: plan.duration_months
      }, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      // Show success toast
      toast({
        title: "Plan Selected",
        description: `You have selected the ${plan.name} with an investment of ${formatCurrency(investmentAmount)}.`,
      });
      
      // Refresh the unread notification count in the header
      // This will show the notification badge for the new notification
      setTimeout(async () => {
        try {
          await api.notifications.getUnreadCount();
        } catch (err) {
          console.error("Error refreshing notification count:", err);
        }
      }, 1000);
      
    } catch (error) {
      console.error("Error selecting plan:", error);
      toast({
        title: "Error",
        description: "Failed to select plan. Please try again.",
        variant: "destructive",
      });
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Function to determine if user's current plan amount falls within this plan's range
  const isCurrentPlan = (plan: Plan) => {
    const userPlanAmount = profile?.plan_amount || 0;
    return userPlanAmount >= plan.min_amount && userPlanAmount <= plan.max_amount;
  };

  return (
    <div className="space-y-8 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-navy-header">Investment Plans</h1>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <p>Loading plans...</p>
        </div>
      ) : (
        <>
          {/* User's Current Plan - Shown on both mobile and desktop */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-navy-header">My Current Plan</h2>
            <div className="overflow-hidden rounded-lg shadow-card border-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gradient-primary text-white">
                    <TableHead className="w-[150px] text-white">Name</TableHead>
                    <TableHead className="text-white">Mobile</TableHead>
                    <TableHead className="text-white">Amount</TableHead>
                    <TableHead className="text-white">Returns</TableHead>
                    <TableHead className="text-white">Month</TableHead>
                    <TableHead className="text-white">Status</TableHead>
                    <TableHead className="text-white">Plan Date</TableHead>
                    <TableHead className="hidden sm:table-cell text-white">Voucher Code</TableHead>
                    <TableHead className="hidden sm:table-cell text-white">Voucher Status</TableHead>
                    <TableHead className="text-right text-white">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow className="bg-gradient-primary/5 hover:bg-gradient-primary/10 transition-colors">
                    <TableCell className="font-medium uppercase">
                      {user?.name || "ANIKET"}
                    </TableCell>
                    <TableCell>{user?.phone || "+919045549926"}</TableCell>
                    <TableCell>{formatCurrency(50000)}</TableCell>
                    <TableCell className="text-primary font-medium">16.0%</TableCell>
                    <TableCell>16</TableCell>
                    <TableCell className="font-medium">Active</TableCell>
                    <TableCell>16-12-2024</TableCell>
                    <TableCell className="hidden sm:table-cell">—</TableCell>
                    <TableCell className="hidden sm:table-cell">—</TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="default"
                        size="sm"
                        className="bg-gradient-primary hover:bg-gradient-primary/90 text-white shadow-card"
                      >
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Available Plans - Consistent design across devices */}
          <h2 className="text-xl font-semibold mb-4 text-navy-header">Available Investment Plans</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <Card 
                key={plan.id} 
                className="shadow-card border-0 h-full flex flex-col transition-all duration-300 hover:shadow-hover hover:-translate-y-1"
              >
                <CardHeader className="pb-2 bg-gradient-primary/10 border-b">
                  <CardTitle className="text-xl text-primary">
                    {plan.name}
                  </CardTitle>
                  <CardDescription className="text-sm font-medium text-navy-header">
                    Investment Range:<br />
                    {formatCurrency(plan.min_amount)} - {formatCurrency(plan.max_amount)}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="pb-2 pt-4">
                  <div className="flex justify-between items-center mb-6 px-2">
                    <div className="text-center bg-gradient-primary/5 rounded-lg p-3 w-[45%]">
                      <div className="text-navy-text text-sm font-medium">Returns</div>
                      <div className="font-bold text-xl text-primary">{plan.returns_percentage}%</div>
                    </div>
                    <div className="text-center bg-gradient-primary/5 rounded-lg p-3 w-[45%]">
                      <div className="text-navy-text text-sm font-medium">Duration</div>
                      <div className="font-bold text-xl text-navy-header">{plan.duration_months} mo</div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-3 text-base border-b pb-2 text-navy-header">Features</h4>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <CheckCircle size={18} className="text-primary" />
                        <span>Monthly returns to wallet</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={18} className="text-primary" />
                        <span>Referral bonuses</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle size={18} className="text-primary" />
                        <span>24/7 support</span>
                      </li>
                      {plan.min_amount >= 100000 && (
                        <li className="flex items-center gap-2">
                          <CheckCircle size={18} className="text-primary" />
                          <span>Premium account manager</span>
                        </li>
                      )}
                      {plan.min_amount >= 500000 && (
                        <li className="flex items-center gap-2">
                          <CheckCircle size={18} className="text-primary" />
                          <span>VIP investment opportunities</span>
                        </li>
                      )}
                    </ul>
                  </div>
                </CardContent>
                
                <CardFooter className="pt-4 mt-auto">
                  <Button 
                    className="w-full bg-gradient-primary hover:bg-gradient-primary/90 text-white shadow-card" 
                    variant="default"
                    onClick={() => handleSelectPlan(plan)}
                  >
                    Select Plan <ChevronRight size={16} className="ml-1" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </>
      )}

    </div>
  );
}
