import { useState, useEffect } from "react";
import { useNavigate, Navigate, Link, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/ui/logo";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { Eye, EyeOff, ArrowRight, Check, RefreshCw } from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import api from "@/utils/api";

export default function Signup() {
  const [formData, setFormData] = useState({
    name: "",
    email: "", // Now optional
    password: "",
    confirmPassword: "",
    phone: "", // Now required
    date_of_birth: "",
    gender: "",
    referral_code: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [otp, setOtp] = useState("");
  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const location = useLocation();
  
  // Extract referral code from URL if present
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const refCode = searchParams.get('ref');
    if (refCode) {
      setFormData(prev => ({ ...prev, referral_code: refCode }));
    }
  }, [location]);

  // Countdown timer for OTP resend
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // If already authenticated, redirect to dashboard
  if (isAuthenticated) {
    return <Navigate to="/" />;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGenderChange = (value: string) => {
    setFormData(prev => ({ ...prev, gender: value }));
  };

  const handleSendOtp = async () => {
    // Validate phone number
    if (!formData.phone) {
      toast({
        variant: "destructive",
        title: "Phone number required",
        description: "Please enter your phone number.",
      });
      return;
    }
    
    setSendingOtp(true);
    
    try {
      await api.auth.sendOTP({
        phone: formData.phone,
        purpose: "signup"
      });
      
      setOtpSent(true);
      setCountdown(60); // 60 seconds countdown for resend
      
      toast({
        title: "OTP sent",
        description: "A verification code has been sent to your phone.",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Failed to send OTP",
        description: error.data?.detail || "Please check your phone number and try again.",
      });
    } finally {
      setSendingOtp(false);
    }
  };
  
  const handleVerifyOtp = async () => {
    if (!otp) {
      toast({
        variant: "destructive",
        title: "OTP required",
        description: "Please enter the verification code sent to your phone.",
      });
      return;
    }
    
    setVerifyingOtp(true);
    
    try {
      await api.auth.verifyOTP({
        phone: formData.phone,
        otp: otp
      });
      
      setOtpVerified(true);
      
      toast({
        title: "OTP verified",
        description: "Your phone number has been verified.",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "OTP verification failed",
        description: error.data?.detail || "Invalid or expired OTP. Please try again.",
      });
    } finally {
      setVerifyingOtp(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (formData.password !== formData.confirmPassword) {
      toast({
        variant: "destructive",
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
      });
      return;
    }

    if (formData.password.length < 8) {
      toast({
        variant: "destructive",
        title: "Password too short",
        description: "Password must be at least 8 characters long.",
      });
      return;
    }
    
    // Check if phone is verified
    if (!otpVerified) {
      toast({
        variant: "destructive",
        title: "Phone verification required",
        description: "Please verify your phone number before registering.",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Register the user
      const userData = {
        name: formData.name,
        phone: formData.phone, // Required field
        password: formData.password,
        email: formData.email || undefined, // Optional field
        date_of_birth: formData.date_of_birth || undefined,
        gender: formData.gender || undefined,
        referral_code: formData.referral_code || undefined,
      };
      
      await api.auth.register(userData);
      
      toast({
        title: "Registration successful",
        description: "Your account has been created. You can now log in.",
      });
      
      // Automatically log the user in
      await login(formData.phone, formData.password);
      navigate("/");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.data?.detail || "Please check your information and try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="bg-card rounded-xl shadow-lg p-8 border border-border">
          <div className="flex justify-center mb-6">
            <Logo size="lg" variant="full" />
          </div>
          
          <h1 className="text-2xl font-bold text-center mb-2">Create Account</h1>
          <p className="text-muted-foreground text-center mb-6">
            Sign up to start your WellVest journey
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                name="name"
                type="text"
                placeholder="John Doe"
                value={formData.name}
                onChange={handleChange}
                required
                className="h-11"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="flex space-x-2">
                <div className="flex-1">
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    autoComplete="tel"
                    className="h-11"
                    disabled={otpSent}
                  />
                </div>
                <Button 
                  type="button" 
                  onClick={handleSendOtp} 
                  disabled={sendingOtp || otpVerified || countdown > 0 || !formData.phone} 
                  className="h-11 whitespace-nowrap"
                  variant={otpVerified ? "outline" : "default"}
                >
                  {otpVerified ? (
                    <>
                      <Check className="h-4 w-4 mr-1" />
                      Verified
                    </>
                  ) : sendingOtp ? (
                    <>
                      <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-1"></div>
                      Sending...
                    </>
                  ) : countdown > 0 ? (
                    `Resend in ${countdown}s`
                  ) : (
                    "Send OTP"
                  )}
                </Button>
              </div>
            </div>
            
            {otpSent && !otpVerified && (
              <div className="space-y-2">
                <Label htmlFor="otp">Verification Code</Label>
                <div className="flex space-x-2">
                  <div className="flex-1">
                    <Input
                      id="otp"
                      type="text"
                      placeholder="Enter 6-digit code"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      required
                      className="h-11"
                      maxLength={6}
                    />
                  </div>
                  <Button 
                    type="button" 
                    onClick={handleVerifyOtp} 
                    disabled={verifyingOtp || !otp || otp.length < 6} 
                    className="h-11 whitespace-nowrap"
                  >
                    {verifyingOtp ? (
                      <>
                        <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-1"></div>
                        Verifying...
                      </>
                    ) : (
                      "Verify OTP"
                    )}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Enter the verification code sent to your phone
                </p>
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="email">Email (Optional)</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="name@example.com"
                value={formData.email}
                onChange={handleChange}
                autoComplete="email"
                className="h-11"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="date_of_birth">Date of Birth (Optional)</Label>
              <Input
                id="date_of_birth"
                name="date_of_birth"
                type="date"
                value={formData.date_of_birth}
                onChange={handleChange}
                className="h-11"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="gender">Gender (Optional)</Label>
              <Select onValueChange={handleGenderChange} value={formData.gender}>
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                  <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  className="h-11 pr-10"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  onClick={() => setShowPassword(!showPassword)}
                  tabIndex={-1}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Must be at least 8 characters long
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                className="h-11"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="referral_code">Referral Code (Optional)</Label>
              <Input
                id="referral_code"
                name="referral_code"
                type="text"
                placeholder="Enter referral code"
                value={formData.referral_code}
                onChange={handleChange}
                className="h-11"
              />
              {formData.referral_code && (
                <p className="text-xs text-green-600 mt-1">
                  Referral code applied!
                </p>
              )}
            </div>
            
            <Button 
              type="submit" 
              className="w-full h-11" 
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center">
                  <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Creating account...
                </div>
              ) : (
                <div className="flex items-center">
                  Sign Up
                  <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              )}
            </Button>
          </form>
          
          <div className="mt-6 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link to="/login" className="text-primary font-medium hover:underline">
              Sign in
            </Link>
          </div>
        </div>
        
        <p className="text-center text-xs text-muted-foreground mt-4">
          © {new Date().getFullYear()} WellVest. All rights reserved.
        </p>
      </motion.div>
    </div>
  );
}
